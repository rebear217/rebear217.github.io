function pL = psiL(x,L)
%del = 1e-7;
%pL = (psi(x,L+del) - psi(x,L-del))/del/2;

%pL = cos(4*x);
pL = cos(2*x);

end