function D = dfMatrix(v,p)

global D2x x Nx A dx

L = p(4);
eps = p(1);
V0 = p(5);

u = v(1:end-1);
lambda = v(end);

Du = eps*D2x - diag(Wpp(u-psi(x,L),p));

D = [Du -ones(Nx,1);
    dx*ones(1,Nx)/(2*A) 0];

end