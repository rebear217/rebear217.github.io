function Vout = binodalF(V,p)

global Nx

v1 = V(1:Nx+1);
v2 = V(Nx+2:2*Nx+2);
L = V(end);

eps = p(1);
a = p(2);
b = p(3);
V0 = p(4);

energy1 = integrate(v1,[eps a b L V0]);
energy2 = integrate(v2,[eps a b L V0]);
v1out = F(v1,[eps a b L V0]);
v2out = F(v2,[eps a b L V0]);

Vout = [v1out ; v2out ; energy1 - energy2];