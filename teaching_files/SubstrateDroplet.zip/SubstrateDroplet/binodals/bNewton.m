function B = bNewton(B,p)

global x stol MaxNewtonIts Nx

% Given an initial guess x at the parameters p, solve ||Fun(x,p)-0||<tol.

v0 = B;

myerror = stol+1;
nsteps = 0;

disp('Now in Binodal Newton ... ');

step = zeros(size(B));

while (myerror > stol) && (nsteps <= MaxNewtonIts)
    RHS = binodalF(v0,p);
    D = dfMatrixB(v0,p);
    step = D\RHS;
    myerror = norm(step,inf)/norm(v0,inf);
    v0 = v0 - step;
    nsteps=nsteps+1;
end


B=v0;
if (myerror <= stol)
  disp('=========================================================================');
  disp(['Newton iteration converged, final step length ',num2str(norm(step,inf)),...
      ' using ',num2str(nsteps),' Newton steps']);
  res = norm(binodalF(v0,p),inf);
  disp(['The corresponding residual is ',num2str(res)]);
  disp(['Parameters are [eps  a  b V0] = [',num2str(p),' ]']);
  disp(['L is ',num2str(B(end)),' and energies are ',num2str(integrate(B(1:Nx+1),[p(1) p(2) p(3) B(end) p(4)])),' and ',num2str(integrate(B(Nx+2:2*Nx+2),[p(1) p(2) p(3) B(end) p(4)]))]);
  disp('=========================================================================');
else
  disp('Convergence has not been obtained, returning vector anyway');
end
