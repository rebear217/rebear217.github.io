function D = dfMatrixB(V,p)

global Nx D2x x dx A

eps = p(1);
a = p(2);
b = p(3);
V0= p(4);

u1 = V(1:Nx);lambda1 = V(Nx+1);
u2 = V(Nx+2:2*Nx+1);lambda2 = V(2*Nx+2);
L = V(end);

p = [eps a b L V0];

D11 = eps*D2x - diag(Wpp(u1-psi(x,L),p));
D12 = -ones(Nx,1);
D13 = zeros(Nx,Nx);
D14 = zeros(Nx,1);
D15 = Wpp(u1-psi(x,L),p).*psiL(x,L);

D21 = dx*ones(1,Nx)/(2*A);
D22 = 0;
D23 = zeros(1,Nx);
D24 = 0;
D25 = -dx*sum(psiL(x,L))/(2*A);

D31 = zeros(Nx,Nx);
D32 = zeros(Nx,1);
D33 = eps*D2x - diag(Wpp(u2-psi(x,L),p));
D34 = -ones(Nx,1);
D35 = Wpp(u2-psi(x,L),p).*psiL(x,L);

D41 = zeros(1,Nx);
D42 = 0;
D43 = dx*ones(1,Nx)/(2*A);
D44 = 0;
D45 = -dx*sum(psiL(x,L))/(2*A);

dLEu1 = dx*sum(-Wp(u1-psi(x,L),p).*psiL(x,L));
dLEu2 = dx*sum(-Wp(u2-psi(x,L),p).*psiL(x,L));

D51 = dx*(-eps*D2x*u1 + Wp(u1-psi(x,L),p));
D52 = 0;
D53 = -dx*(-eps*D2x*u2 + Wp(u2-psi(x,L),p));
D54 = 0;
D55 = dLEu1 - dLEu2;

D = [D11 D12 D13 D14 D15; D21 D22 D23 D24 D25; ; D31 D32 D33 D34 D35; ; D41 D42 D43 D44 D45; D51' D52 D53' D54 D55];

end