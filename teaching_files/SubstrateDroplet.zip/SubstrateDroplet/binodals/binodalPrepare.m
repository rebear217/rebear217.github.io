function [b,P] = binodalPrepare(inP,j1,j2)

global Nx

p1 = inP(:,j1);
p2 = inP(:,j2);

b = zeros(2*Nx+3,1);

b(1:Nx+1) = p1(1:Nx+1);%sol1
b(Nx+2:2*Nx+2) = p2(1:Nx+1);%sol2

p = p1(Nx+2:end);%parameter values
b(end) = p(4);%put L into the state vector
P = [p(1:3) ; p(5)];% eps a b (miss out L) V0

%check that parameter values are close
disp(['As a check, this should be small : ',num2str(norm(p1(Nx+2:end) - p2(Nx+2:end)))]);
%and that the solutions are close in energy (and all other points too)
disp(['this is the nonlinear residual inf norm : ',num2str(norm(binodalF(b,P),inf))]);
