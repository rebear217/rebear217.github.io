function bPlot2(bpath)

global x Nx dx phaseParam phaseparameters

[n m] = size(bpath);
energy = zeros(1,m);
itgl = energy;
V1norms = max(abs(bpath(1:Nx,:)));
V2norms = max(abs(bpath(Nx+2:2*Nx+1,:)));

Ls = bpath(2*Nx + 3,:);
epsilons = bpath(2*Nx+4,:);
as = bpath(2*Nx+5,:);
bs = bpath(2*Nx+6,:);
V0s = bpath(2*Nx+7,:);

for j = 1:m
    [energy(j),itgl(j)] = integrate(bpath(1:Nx+1,j),[epsilons(j) as(j) bs(j) Ls(j) V0s(j)]);
end


plot(Ls,bpath(2*Nx + 3 + phaseParam,:),'-k','Linewidth',2);hold on;
xlabel('L');
ylabel(phaseparameters(phaseParam));
title('Phase curve');
axis tight;
