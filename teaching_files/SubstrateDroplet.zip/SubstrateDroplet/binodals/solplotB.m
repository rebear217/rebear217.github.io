function solplotB(bpath)

global x Nx dx A phaseParam phaseparameters

[n m] = size(bpath);

fstep = dx/10;
fx = -A:fstep:A;

Ls = bpath(2*Nx + 3,:);
epsilons = bpath(2*Nx+4,:);
as = bpath(2*Nx+5,:);
bs = bpath(2*Nx+6,:);
V0s = bpath(2*Nx+7,:);

NPTS = Nx+1;

subplot(1,2,1);
bPlot2(bpath);
plot(Ls(1),bpath(2*Nx + 3 + phaseParam,1),'.b','Markersize',16);
plot(Ls(1),bpath(2*Nx + 3 + phaseParam,1),'.b','Markersize',16);

for j = 1:m
    v1 = bpath(1:Nx+1,j);
    v2 = bpath(Nx+2:2*Nx+2,j);

    L = Ls(j);
    
    epsilon = epsilons(j);
    a = as(j);
    b = bs(j);
    V0 = V0s(j);

    subplot(1,2,1);
    [energy1,itgl1] = integrate(v1,[epsilons(j) as(j) bs(j) Ls(j) V0s(j)]);
    [energy2,itgl2] = integrate(v2,[epsilons(j) as(j) bs(j) Ls(j) V0s(j)]);
    unplot;unplot;
    plot(Ls(j),bpath(2*Nx + 3 + phaseParam,j),'.b','Markersize',16);
    plot(Ls(j),bpath(2*Nx + 3 + phaseParam,j),'or','Markersize',6);
    
    subplot(1,2,2);
    hold off;
    fineplot(v1(1:Nx),fstep,L);
    hold on;
    xlabel('spatial coordinate');
    ylabel('interface');
    str = strcat(phaseparameters(phaseParam),' = ');
    fineplot(v2(1:Nx),fstep,L,'--b');
    hold on;
    axis([-A A min(psi(x,L))-0.1 max([max(v2(1:Nx)) max(v1(1:Nx))])*1.15]);
    strL = strcat('Coexisting solutions at L = ',num2str(L),', ',str);
    title(strcat(strL,num2str(bpath(2*Nx+3+phaseParam,j))));
    drawnow;
end
