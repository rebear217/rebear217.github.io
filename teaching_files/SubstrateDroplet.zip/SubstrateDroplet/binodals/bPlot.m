function bPlot(bpath)

global x Nx dx A phaseParam phaseparameters

[n m] = size(bpath);
energy = zeros(1,m);
itgl = energy;
energy2 = energy;
itgl2 = energy;
b1norms = itgl;b2norms = itgl;

Ls = bpath(2*Nx + 3,:);
epsilons = bpath(2*Nx+4,:);
as = bpath(2*Nx+5,:);
bs = bpath(2*Nx+6,:);
V0s = bpath(2*Nx+7,:);
lambda1s = bpath(Nx+1,:);
lambda2s = bpath(2*Nx+2,:);


for j = 1:m
    b1norms(j) = max(abs(bpath(1:Nx,j) - psi(x,Ls(j)))) - min(abs(bpath(1:Nx,j) - psi(x,Ls(j))));
    b2norms(j) = max(abs(bpath(Nx+2:2*Nx+1,j) - psi(x,Ls(j)))) - min(abs(bpath(Nx+2:2*Nx+1,j) - psi(x,Ls(j))));

    [energy(j),itgl(j)] = integrate(bpath(1:Nx+1,j),[epsilons(j) as(j) bs(j) Ls(j) V0s(j)]);
    [energy2(j),itgl2(j)] = integrate(bpath(Nx+2:2*Nx+2,j),[epsilons(j) as(j) bs(j) Ls(j) V0s(j)]);
end

hold on;
plot(bpath(2*Nx + 3 + phaseParam,:),energy,'-k','Linewidth',2);ylabel('energy');
xlabel(phaseparameters(phaseParam));
