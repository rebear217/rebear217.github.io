function Bpath = bRun(p,j1,j2)

global Nx x stol MaxNewtonIts dt dtMin dtMax StepsAroundCurve phaseParam phaseparameters

stol = 1e-13;
StepsAroundCurve = 100;
MaxNewtonIts = 100;

%%%%%%%%%%%%%%%
phaseparameters = { 'epsilon' , 'a' , 'b', 'V0' };
phaseParam = 4;
%%%%%%%%%%%%%%%%

direction = 1;
if (nargin == 2) && (j1 == -1)
    direction = -1;
end

dt = 0.01;dtMax = 0.1;dtMin = 0.01;

if (nargin > 2)
    [B,P] = binodalPrepare(p,j1,j2);
    eps = P(1); a = P(2); b = P(3); V0 = P(4);
    L = B(end);
    B = bNewton(B,[eps a b V0]);
    dt = dt * direction;
    Bpath = [B ;eps ;a ;b ;V0];
else
    B = p(1:2*Nx + 3,end);
    L = p(2*Nx+3,end);
    eps = p(2*Nx + 4,end);
    a = p(2*Nx + 5,end);
    b = p(2*Nx + 6,end);
    V0 = p(2*Nx + 7,end);
    [n m] = size(p);
    if (m > 1)
        direction = sign(p(2*Nx + 3 + phaseParam,end) - p(2*Nx + 3 + phaseParam,end-1));
    end
    
    dt = dt * direction;
    
    [Bpath,returnerror] = bcont(B,[eps a b V0],phaseParam);
    Bpath = [p Bpath];
end
