function [path,returnerror]=bcont(v,p,ip)

% Continue the solution of Fun(x,p)=0 in the ip-th parameter
% using x as the initial guess for a point on the curve.

global x StepsAroundCurve MaxNewtonIts stol dt dtMax dtMin Nx

epsilon = p(1);
a = p(2);
b = p(3);
V0 = p(4);
L = v(end);

NPTS = 2*Nx + 3;
returnerror = 0;

path = zeros(NPTS+4,StepsAroundCurve);
path(NPTS+1,:) = epsilon;
path(NPTS+2,:) = a;
path(NPTS+3,:) = b;
path(NPTS+4,:) = V0;

x0=v;
p0=p(ip);
disp(['Starting continuation from parameter = ',num2str(p0)]);

Dp = bPderiv(x0,p,ip);
RHS = zeros(NPTS+1,1);
w = RHS; step = RHS;
RHS(NPTS+1) = 1;
D = dfMatrixB(x0,p);
z0 = -D\Dp;

disp('Found initial predictor');

frac=sqrt(dot(z0,z0)+1);
s0 = z0/frac;
sig0= 1/frac;

step=zeros(NPTS+1,1);
w = zeros(NPTS+1,1);

%fig = figure;

for its=1:StepsAroundCurve,

  p(ip)=p0;

  xg=x0+dt*s0;
  pg=p0+dt*sig0;

  NewtonIts = 0;

  Dp = bPderiv(xg,p,ip);
  myerror = 1;
  
  while (myerror > stol) && (NewtonIts<=MaxNewtonIts),

    p(ip)=pg;
    rhsx = -binodalF(xg,p);
    rhss = dt - s0'*(xg-x0) - sig0*(pg-p0);
    myrhs = [rhsx ; rhss];
    
    D = bfulldf(xg,p,Dp,s0,sig0);
    step = D\myrhs;

    next=[xg ; pg] + step;
    myerror = norm(step,inf)/norm(next,inf);
    
%    plotyy(x,xg(1:Nx),x,xg(Nx+1:2*Nx));
%    figure(fig);
%    xlabel(['Size of last cont Newton step ',num2str(myerror)]);
%    drawnow;
    
    xg=next(1:NPTS);
    pg=next(NPTS+1);
    p(ip) = pg;
    Dp = bPderiv(xg,p,ip);

    NewtonIts = NewtonIts+1;
    
  end
  
  if (NewtonIts > MaxNewtonIts)
    disp('Newton method not converging');returnerror = 1;
    path = path(:,1:its-1);
    return
  end
  
  if (NewtonIts <= 2)
      dt = 11*dt/10;
      if (abs(dt) > dtMax)
          dt = sign(dt)*dtMax;
      end
  end

  if (NewtonIts >= 4)
      dt = 1*dt/2;
      if (abs(dt) < dtMin)
          dt = sign(dt)*dtMin;
      end
  end

  path(1:NPTS,its)=xg;
  path(NPTS+ip,its)=pg;

  if its > 2
    if (path(NPTS+ip,its) - path(NPTS+ip,its-1)) * (path(NPTS+ip,its-1) - path(NPTS+ip,its-2)) < 0;
        disp('-------------------------------------------------------------------');
        disp(['Critical point found near phase point [',num2str(pg),' , ',num2str(xg(end)),' ]']);
        disp('-------------------------------------------------------------------');
    end
  end
  
  
  D = bfulldf(xg,p,Dp,s0,sig0);
  w = D\RHS;

  w=w./norm(w,2);
  s0=w(1:NPTS);
  sig0=w(NPTS+1);

  x0=xg;
  p0=pg;
 
  if mod(its,10)==0,
      disp([num2str(floor(100*its/StepsAroundCurve)),' Percent complete']);
      disp(['Last parameter equals ',num2str(pg)]);
      disp(['Last no of Newton iterations is ',num2str(NewtonIts),' and dt = ',num2str(dt)]);
      disp(['Last nonlinear inf norm residual ',num2str(norm(binodalF(xg,p),inf))]);
  end
  
end

return