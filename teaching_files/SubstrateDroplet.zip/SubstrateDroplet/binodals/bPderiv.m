function pd=bPderiv(x,p,i)

% Calculates the partial derivative of Fun(x,p) wrt the i-th entry in p
h=1e-7;

ei=zeros(size(p));
ei(i)=h;
pd1=binodalF(x,p+ei);
pd2=binodalF(x,p-ei);

pd=(pd1-pd2)/h/2;