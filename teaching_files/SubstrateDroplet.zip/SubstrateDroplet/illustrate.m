function illustrate(p,positions,folds)

global Nx dx A x parameters parameter

[N M] = size(p);
energy = zeros(1,M);itgl = energy;

fig = figure;

K = length(positions);

subplot(1,K+1,1);
if nargin == 3
    bifplot2(p,folds);
else
    bifplot2(p);
end

for j = 1:K
    figure(fig);
    P = p(:,positions(j));
    subplot(1,K+1,1);
    [energy,itgl] = integrate(P(1:Nx+1),[P(end-4) P(end-3) P(end-2) P(end-1) P(end)]);
    plot(P(Nx+1+parameter),energy,'.b','Markersize',20);hold on;
    text(0.8*P(Nx+1+parameter),0.9*energy,num2str(j));
    axis tight;
    hold on;
    subplot(1,K+1,j+1);
    solplot2(P);
    if j > 1
        xlabel('');
        ylabel('');
        set(gca,'XTick',[]);
        set(gca,'YTick',[]);
    end
%    axis([-A A min(psi(x,P(end-1))) 0]);
    title(num2str(j));
end

