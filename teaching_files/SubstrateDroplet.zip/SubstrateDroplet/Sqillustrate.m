function Sqillustrate(p,positions)

global Nx dx A x parameters parameter

[N M] = size(p);
energy = zeros(1,M);itgl = energy;

fig = figure;

K = length(positions);

for j = 1:K
    figure(fig);
    P = p(:,positions(j));
    hold on;
    subplot(1,K,j);
    solplot(P);
%    xlabel(num2str(P(Nx+1+parameter),'%2.3f'));
    if j==1
        ylabel('Interface/substrate');
    end
%    title(num2str(j));
    title([num2str(j),':',num2str(P(Nx+1+parameter),'%2.3f')]);
    xlabel('');
    axis([-A A min(psi(x,P(end-1))) 11]);
end
