function [lambda,x] = eigenvalueOne(A,x)

[n,m] = size(A);

if nargin == 1
    x = rand(n,1);
end

maxits = 100;
tolerance = 1e-10;
error = 1;
its = 0;

while (error > tolerance) && (its < maxits)
    z = A*x;y = z/norm(z,2);
    error = norm(x-y,2);
    x = y;
    its = its + 1;
    lambda = dot(x,A*x)/dot(x,x)
end

if (error > tolerance)
    lambda = NaN;
end

return

function [mu,y] = eigenvalueTwo(A,lambda,x)

[n,m] = size(A);

y = rand(n,1);

maxits = 100;
tolerance = 1e-10;
error = 1;
its = 0;

while (error > tolerance) & (its < maxits)
    Y = A*y;
    Y1 = Y - dot(Y,x)*x/dot(x,x);
    Y2 = Y1/norm(Y1,2);
    error = norm(Y2-y,2);
    y = Y2;
    its = its + 1;
end

mu = NaN;
if (error < tolerance)
    mu = dot(y,A*y)/dot(y,y);
end

return