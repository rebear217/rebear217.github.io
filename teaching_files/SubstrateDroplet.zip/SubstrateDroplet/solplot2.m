function solplot2(path)

global Nx x dx A parameter D2x parameters

NPTS = Nx+1;
[N M] = size(path);

    v = path(1:NPTS,1);
    epsilon = path(NPTS+1);
    a = path(NPTS+2);
    b = path(NPTS+3);
    L = path(NPTS+4);
    V0 = path(NPTS+5);
    engy = integrate(v,[epsilon a b L V0]);

    u = v(1:end-1);
    lambda = v(end);

    fineplot(u,dx/10,L);

    str = strcat(parameters(parameter),' = ',num2str(path(NPTS+parameter,1)));
    xlabel('spatial coordinate (x)');
    ylabel('l(x)');
    title('gas-liquid interface');
    drawnow;