function [path,foldPoints] = run(path,oldfolds)

global dtMax dtMin StepsAroundCurve dt inittol A Nx D2x D x ...
    dx conttol tol MaxNewtonIts parameters parameter

A = pi; Nx = 150;

%1 for epsilon and 2 for a
parameters = { 'epsilon' , 'a' , 'b', 'L' , 'V0' };
parameter = 5;
findfold = 1;

tol = 1e-10; conttol = 1e-10; MaxNewtonIts = 300;

% x variable in [-A,A], Fourier:
%%%%%%%%%%%%%%%%%%
dx = 2*A/Nx;
x = -A+dx*(1:Nx)';
D2x = (pi/A)^2*toeplitz([-1/(3*(dx/A)^2)-1/6 .5*(-1).^(2:Nx)./sin((pi*dx/A)*(1:Nx-1)/2).^2]);
column = [0 .5*(-1).^(1:Nx-1).*cot((1:Nx-1)*dx/2)]';
D = toeplitz(column,column([1 Nx:-1:2]));
%%%%%%%%%%%%%%%%%%

if nargin == 1
    oldfolds = [];
end

% Grid and initial data:
if length(path) == length(parameters)
    epsilon = path(end-4);
    a = path(end-3);
    b = path(end-2);
    L = path(end-1);
    V0 = path(end);

    if isempty(oldfolds)
%Some different initial guesses - just in case solution branches are hard to find
%        u = psi(x,L) + 0.02;
%        u = psi(x,L)+ exp(-(x+pi/6).^2)+ exp(-(x - pi/6).^2);
        u = ones(size(x));

        u = V0*u/(dx*sum(u)/(2*A));
        lambda = -dx*sum(Wp(u-psi(x,L),[epsilon a b L V0])/(2*A));
        v = [u;lambda];
    else
        v = oldfolds(1:Nx+1);

    end
    v = Newton(v,[epsilon a b L V0]);
    foldPoints = [];
    oldfolds = [];
    path = [v ; epsilon ; a ; b ; L ; V0];
    u = v(1:end-1);
    disp(['Volume check - this should be zero : ',num2str(sum(u-psi(x,L))*dx/(2*A)-V0)]);
    
    direction = -1;
    M = 0;
else
    [N M] = size(path);
    if (Nx + 1~= N-5)
        error('Path dimensions don''t match run dimensions');
    end
    v = path(1:N-5,end);
    epsilon = path(N-4,end);
    a = path(N-3,end);
    b = path(N-2,end);
    L = path(N-1,end);
    V0 = path(N,end);

    if (M > 1),
        direction = sign(path(N-length(parameters) + parameter,end) - path(N-length(parameters) + parameter,end-1));
    else
        direction = -1;
    end
end

StepsAroundCurve = 250;
dt = direction*0.1; dtMax = 0.4; dtMin = 0.05;

[newpath,foldPoints,errors]=cont(v,[epsilon a b L V0],parameter,findfold,M);
foldPoints = [oldfolds foldPoints];

    path = [path newpath];
    ulambda = newpath(1:end-5,end);
    epsilon = newpath(end-4,end);
    a = newpath(end-3,end);
    b = newpath(end-2,end);
    L = newpath(end-1,end);
    V0 = newpath(end,end);
    
    fineplot(ulambda(1:end-1),dx/10,L);
    title('Final Solution on Branch'); 


disp('--------');
disp('Finished');

end
