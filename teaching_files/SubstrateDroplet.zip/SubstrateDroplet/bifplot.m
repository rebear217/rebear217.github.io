function bifplot(P,folds,stability)

global Nx dx A parameter parameters x D2x

NPTS = Nx+1;
[N M] = size(P);

if nargin == 1
    folds = [];
end

energy = zeros(1,M);itgl = energy; Zenergy = energy;
b1norms = energy;b2norms = energy;mins = energy; maxs = energy;
norms = dx*(sum(P(1:NPTS,:).^2)).^(1/2);

epsilons = P(NPTS+1,:);
as = P(NPTS+2,:);
bs = P(NPTS+3,:);
Ls = P(NPTS+4,:);
V0s = P(NPTS+5,:);

for j = 1:M
    mins(j) = min(abs(P(1:Nx,j) - psi(x,Ls(j))));
    maxs(j) = max(abs(P(1:Nx,j) - psi(x,Ls(j))));
    [energy(j),itgl(j)] = integrate(P(1:NPTS,j),[P(end-4,j) P(end-3,j) P(end-2,j) P(end-1,j) P(end,j)]);
end

lambdas = P(NPTS,:);

paramValues = P(NPTS + parameter,:);

subplot(1,2,1);hold on;
plot(paramValues,energy,'-b','Linewidth',1);

ylabel('energy');
xlabel(parameters(parameter));

subplot(1,2,2);
hold on;
plot(paramValues,maxs-mins,'-r','Linewidth',1);
ylabel('Maximal - minimal height above substrate');
xlabel(parameters(parameter));
axis tight;

if not(isempty(folds))
    F = folds(1,:);
    for j = 1:length(F)
        subplot(1,2,1);
        hold on;
        plot(paramValues(F(j)),energy(F(j)),'.r','Markersize',15);
        subplot(1,2,2);
        hold on;
        plot(paramValues(F(j)),maxs(F(j)) - mins(F(j)),'.b','Markersize',15);
    end
end