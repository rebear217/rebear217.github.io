function bifplot2(p,folds)

global Nx parameters parameter

[N M] = size(p);

energy = zeros(1,M);itgl = energy;
for j = 1:M
    [energy(j),itgl(j)] = integrate(p(1:Nx+1,j),[p(end-4,j) p(end-3,j) p(end-2,j) p(end-1,j) p(end,j)]);
end
epsilons = p(Nx+2,:);
as = p(Nx+3,:);
bs = p(Nx+4,:);
Ls = p(Nx+5,:);
V0s = p(Nx+6,:);

paramValues = p(Nx+1+parameter,:);

plot(paramValues,energy,'-b');hold on;
%plot(p(Nx+1+parameter,:),energy,'.b','Markersize',10);

xlabel(parameters(parameter));
ylabel('energy');
axis tight;

if nargin > 1
    if not(isempty(folds))
        F = folds(1,:);
        for j = 1:length(F)
            hold on;
            plot(paramValues(F(j)),energy(F(j)),'.r','Markersize',15);
        end
    end
end