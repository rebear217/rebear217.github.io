function wppp = Wppp(v,p)
    a = p(2);
    b = p(3);
    wppp = -24*a./v.^5 - 60*b./v.^6;
%    wppp = -a*exp(-v) - 8*b*exp(-2*v);

%    wppp = -a*exp(-v) + 8*b*exp(-2*v) - 27*exp(-3*v);

%    wppp = -exp(-v);

end