clc

[P0,F0] = run([0.1 -1 1 1 8]);
[P1,F1] = run([0.1 -2 1 1 8]);
[P1,F1] = run(P1,F1);
[P1,F1] = run(P1,F1);
[P2,F2] = run([0.1 -3 1 1 8]);
[P2,F2] = run(P2,F2);
[P2,F2] = run(P2,F2);
[P2,F2] = run(P2,F2);
[P2,F2] = run(P2,F2);
[P3,F3] = run([0.1 -3.5 1 1 8]);
[P3,F3] = run(P3,F3);
[P3,F3] = run(P3,F3);
[P3,F3] = run(P3,F3);
[P3,F3] = run(P3,F3);
[P3,F3] = run(P3,F3);
[P3,F3] = run(P3,F3);

bifplot(P2,F2);
bifplot(P1,F1);
bifplot(P0,F0);
