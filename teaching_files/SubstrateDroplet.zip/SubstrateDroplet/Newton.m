function V = Newton(v,p)

global x tol MaxNewtonIts restart gmsteps gmtol dx Nx

% Given an initial guess x at the parameters p, solve ||Fun(x,p)-0||<tol.

v0 = v;

myerror = tol+1;
nsteps = 0;

disp('In Newton now');

fig = gcf;
step = zeros(size(v));

while (myerror > tol) && (nsteps <= MaxNewtonIts)
    RHS = F(v0,p);
    D = dfMatrix(v0,p);
    step = ((RHS')/D')';
    myerror = norm(step,inf)/norm(v0,inf);
    plot(x,v0(1:end-1),x,psi(x,p(4)));
    figure(fig);
    xlabel(['Size of last Newton step ',num2str(myerror)]);
    drawnow;
    v0 = v0 - step;
    nsteps=nsteps+1;
end

close(fig);
drawnow;

disp('Initial Newton iteration finished');

if (myerror <= tol)
  V=v0;
  disp('================================================');
  disp(['Newton iteration converged, final step length ',num2str(norm(step,inf)),...
      ' using ',num2str(nsteps),' Newton steps']);
  res = norm(F(v0,p),inf);
  disp(['The corresponding residual is ',num2str(res)]);
  disp('================================================');
else
  disp('Convergence has not been obtained, returning vector anyway');
  V = v0;
end

