function wp = Wp(v,p)
    a = p(2);
    b = p(3);
    wp = -2*a./v.^3 - 3*b./v.^4;
%    wp = -a*exp(-v) -2*b*exp(-2*v);
%    wp = -a*exp(-v) + 2*b*exp(-2*v) - 3*exp(-3*v);
%    wp = a - exp(-v);

end