function vout = F(v,p)

global D2x D x dx A

L = p(4);
eps = p(1);
V0 = p(5);

%vout = eps*D2x*v - Wp(v-psi(x,L),p) + Wp(phi(x,L)-v,p);

u = v(1:end-1);
lambda = v(end);

uout = eps*D2x*u - Wp(u-psi(x,L),p) - lambda;
lout = sum(u-psi(x,L))*dx/(2*A) - V0;

vout = [uout;lout];

end