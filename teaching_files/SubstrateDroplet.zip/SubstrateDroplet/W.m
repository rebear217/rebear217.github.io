function w = W(v,p)
    eps = p(1);%sigma
    a = p(2);
    b = p(3);
%    L = p(4);
%    V0 = p(5);

    w = a./v.^2 + b./v.^3;

%    w = a*exp(-v) + b*exp(-2*v);
%    w = a*exp(-v) - b*exp(-2*v) + exp(-3*v);
%    w = a*v + exp(-v);
end
