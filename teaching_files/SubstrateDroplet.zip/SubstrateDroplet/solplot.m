function solplot(path,folds)

global Nx x dx A parameter D2x parameters

NPTS = Nx+1;
[N M] = size(path);

    subplot(1,2,1);
    if nargin == 2
        bifplot2(path,folds);
    else
        bifplot2(path);
    end

    v = path(1:NPTS,1);
    epsilon = path(NPTS+1,1);
    a = path(NPTS+2,1);
    b = path(NPTS+3,1);
    L = path(NPTS+4,1);
    V0 = path(NPTS+5,1);
    engy = integrate(v,[epsilon a b L V0]);
    plot(path(NPTS + parameter,1),engy,'.r','Markersize',15);

V = rand(Nx,1);
options.isreal = 1;
options.disp = 0;

for j = 1:M
    v = path(1:NPTS,j);
    epsilon = path(NPTS+1,j);
    a = path(NPTS+2,j);
    b = path(NPTS+3,j);
    L = path(NPTS+4,j);
    V0 = path(NPTS+5,j);
    engy = integrate(v,[epsilon a b L V0]);
    
    u = v(1:end-1);

    
    lambda = v(end);

    subplot(1,2,1);
    unplot;
    plot(path(NPTS + parameter,j),engy,'.b','Markersize',15);

    subplot(1,2,2);
    fineplot(u,dx/10,L);

    str = strcat(parameters(parameter),' = ',num2str(path(NPTS+parameter,j)));
    xlabel('spatial coordinate (x)');
    ylabel('l(x)');
    title('gas-liquid interface');
    drawnow;
end
