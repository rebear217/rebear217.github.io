function [energy,itgl] = integrate(v,p)

global D2x x dx

eps = p(1);
a = p(2);
b = p(3);
L = p(4);
V0 = p(5);

u = v(1:end-1);
lambda = v(end);

itgl = sum(u)*dx;
energy = dx*sum(-eps*u.*(D2x*u)/2 + W(u-psi(x,L),[eps a b L V0]));