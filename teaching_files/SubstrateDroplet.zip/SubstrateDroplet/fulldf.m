function D = fulldf(x,p,Dp,s0,sig0)

D = [dfMatrix(x,p) Dp ;
    s0' sig0];
%D = D';

%D = [dfMatrix(x,p) s0 ;    Dp' sig0]';

%D = [dfAnalytic(K(1:end-1),x,p) + Dp*K(end) ; dot(s0,K(1:end-1)) + sig0*K(end)];

end