function [path,foldPoints,returnerror]=cont(x,p,ip,FindFold,startPoint)

% Continue the solution of Fun(x,p)=0 in the ip-th parameter
% using x as the initial guess for a point on the curve.

global StepsAroundCurve MaxNewtonIts conttol dt dtMax dtMin Nx restart gmsteps gmtol parameters

epsilon = p(1);
a = p(2);
b = p(3);
L = p(4);
V0 = p(5);

NPTS = Nx+1;
returnerror = 0;

foldPoints = [];
path = zeros(NPTS+5,StepsAroundCurve);
path(NPTS+1,:) = epsilon;
path(NPTS+2,:) = a;
path(NPTS+3,:) = b;
path(NPTS+4,:) = L;
path(NPTS+5,:) = V0;

x0=x;
p0=p(ip);
disp(['Starting continuation from parameter = ',num2str(p0)]);

Dp = Pderiv(x0,p,ip);
RHS = zeros(NPTS+1,1);
w = RHS; step = RHS;
RHS(NPTS+1) = 1;

D = dfMatrix(x0,p);    z0 = ((-Dp')/D')';

disp('Found initial predictor');

frac=sqrt(dot(z0,z0)+1);
s0 = z0/frac;
sig0= 1/frac;

step=zeros(NPTS+1,1);
w = zeros(NPTS+1,1);

for its=1:StepsAroundCurve,

  p(ip)=p0;

  xg=x0+dt*s0;
  pg=p0+dt*sig0;

  NewtonIts = 0;

  Dp = Pderiv(xg,p,ip);
  myerror = 1;
  
  while (myerror > conttol) && (NewtonIts<=MaxNewtonIts),

    p(ip)=pg;
    rhsx = -F(xg,p);
    rhss = dt - s0'*(xg-x0) - sig0*(pg-p0);
    myrhs = [rhsx ; rhss];
    

    fullD = fulldf(xg,p,Dp,s0,sig0);
    step = (myrhs'/fullD')';
%    step = ((myrhs')/fullD');
%    step = cgs(fullD,myrhs)';
    next=[xg ; pg] + step;
    myerror = norm(step,inf)/norm(next,inf);
    xg=next(1:NPTS);
    pg=next(NPTS+1);
    p(ip) = pg;
    Dp = Pderiv(xg,p,ip);

    NewtonIts = NewtonIts+1;
    
  end
  
  if (NewtonIts > MaxNewtonIts)
    disp('Newton method not converging');returnerror = 1;
    path = path(:,1:its-1);
    foldPoints = foldPoints';
    return
  end
  
  if (NewtonIts <= 2)
      dt = 11*dt/10;
      if (abs(dt) > dtMax)
          dt = sign(dt)*dtMax;
      end
  end

  if (NewtonIts >= 4)
      dt = 1*dt/2;
      if (abs(dt) < dtMin)
          dt = sign(dt)*dtMin;
      end
  end

  path(1:NPTS,its)=xg;
  path(NPTS+ip,its)=pg;

%  [w,gmflagw] = gmres(@(K)fulldf(K,xg,p,Dp,s0,sig0),RHS,restart,gmtol,gmsteps,@(b)fullprecon(l,u,r,q,b));
  fullD = fulldf(xg,p,Dp,s0,sig0);
  w = ((RHS')/fullD')';

  w=w./norm(w,2);
  s0=w(1:NPTS);
  sig0=w(NPTS+1);

  x0=xg;
  p0=pg;
  
  if (its > 2)
    folddetected = ((pg-path(NPTS+ip,its-1))*(path(NPTS+ip,its-1)-path(NPTS+ip,its-2)) < 0);
    if folddetected
        disp('=====================');
        disp(['Found fold near ',num2str(pg)]);
        disp('=====================');
        if FindFold
            approxk = path(1:NPTS,its) - path(1:NPTS,its-2);approxk = NPTS*approxk/sum(approxk);
            foldPoints = [foldPoints ; startPoint+its approxk'];
        end
    end
  end

  
  if mod(its,20)==1,
      disp([num2str(floor(100*its/StepsAroundCurve)),' Percent complete']);
      disp(['Last parameter equals ',num2str(pg)]);
      disp(['Last no of Newton iterations is ',num2str(NewtonIts),' and dt = ',num2str(dt)]);
      disp(['Last nonlinear residual ',num2str(norm(F(xg,p),inf))]);
  end
  
end

foldPoints = foldPoints';

return