function List = findBinodals(p,tolerance)

global Nx dx

NPTS = Nx;
[N M] = size(p);

energy = zeros(1,M);itgl = energy;

for j = 1:M
    energy(j) = integrate(p(1:NPTS,j),[p(end-3,j) p(end-2,j) p(end-1,j) p(end,j)]);
end
epsilons = p(NPTS+1,:);
as = p(NPTS+2,:);
bs = p(NPTS+3,:);
Ls = p(NPTS+4,:);

list = zeros(M);list = sparse(list);
for j = 1:(floor(M/2) + 1)
    l = find(abs(as(j)-as) < tolerance);
    L = find(abs(energy(l)-energy(j)) < tolerance);
    if length(L) > 1
        list(j,l(L)) = 1;
    end
end

for j = 1:M
    list(j,j) = 0;
end

[rows,cols] = find(list);
List = [rows cols];