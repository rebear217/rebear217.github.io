function [path,foldPoints,returnerror]=cont(x,p,ip,FindFold,startPoint)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Step 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Continue the solution of Fun(x,p)=0 in the ip-th parameter
% using x as the initial guess for a point on the curve.
% We assume that step 1 of the PAL methodology has aleady been undertaken
% and solutions x and p found - perhaps using a Newton method.

global StepsAroundCurve MaxNewtonIts conttol dt dtMax dtMin Nx restart gmsteps gmtol parameters

%first find the parameter values of the first solution on the curve to be computed
epsilon = p(1); a = p(2); b = p(3); L = p(4);

NPTS = Nx;
returnerror = 0;

%we may be checking for fold bifurcations, so let's define a place to put them
foldPoints = [];
%let's initialise the entire path
path = zeros(NPTS+3,StepsAroundCurve);
path(NPTS+1,:) = epsilon;
path(NPTS+2,:) = a;
path(NPTS+3,:) = b;
path(NPTS+4,:) = L;

%the initial solution x and parameter value vector p
x0=x;
p0=p(ip);
disp(['Starting continuation from parameter = ',num2str(p0)]);

%begin by computing the dervative of the EL equations with respect to the
%ip-th parameter

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Step 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

Dp = Pderiv(x0,p,ip);
RHS = zeros(NPTS+1,1);
w = RHS; step = RHS;
RHS(NPTS+1) = 1;
%find the initial direction vector
D = dfMatrix(x0,p);    z0 = ((-Dp')/D)';

disp('Found initial predictor');
%now normalise it to have have length 1
frac=sqrt(dot(z0,z0)+1);
s0 = z0/frac;
sig0= 1/frac;
%in terms of the lecture notes, s0 = rho_d and sig0 = T_d

step=zeros(NPTS+1,1);
w = zeros(NPTS+1,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Step 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for its=1:StepsAroundCurve,

  p(ip)=p0;

  %We now assume that a solution on the curve has been found, and we know the
  %direction vector that the curve heads in to form a guess for the next
  %solution

  %a predictor step : form the next initial guess using dt (called ds in the notes)
  xg=x0+dt*s0;
  pg=p0+dt*sig0;

  NewtonIts = 0;

  Dp = Pderiv(xg,p,ip);
  myerror = 1;
  
  while (myerror > conttol) && (NewtonIts<=MaxNewtonIts),

    p(ip)=pg;
    %the next two lines contain the extended right-hand side
    rhsx = -F(xg,p);
    rhss = dt - s0'*(xg-x0) - sig0*(pg-p0);
    myrhs = [rhsx ; rhss];
    
    %fullD contains the extended PAL Newton iteration matrix that contains
    %both the Hessian and the derivative of the contraint function called
    %g in the notes
    fullD = fulldf(xg,p,Dp,s0,sig0);
    %by inverting fullD, we computed the step require for the iteration
    step = myrhs'/fullD;
    next=[xg ; pg] + step';%the Newton update
    myerror = norm(step,inf)/norm(next,inf);
    %update the guesses for next solution xg and parameter value pg
    xg=next(1:NPTS);
    pg=next(NPTS+1);
    p(ip) = pg;
    Dp = Pderiv(xg,p,ip);

    NewtonIts = NewtonIts+1;
    
  end
  
  if (NewtonIts > MaxNewtonIts)
    disp('Newton method not converging');returnerror = 1;
    path = path(:,1:its-1);
    return
  end
  
  if (NewtonIts <= 2)
      dt = 11*dt/10;
      if (abs(dt) > dtMax)
          dt = sign(dt)*dtMax;
      end
  end

  if (NewtonIts >= 4)
      dt = 1*dt/2;
      if (abs(dt) < dtMin)
          dt = sign(dt)*dtMin;
      end
  end

%We have found a solution, so let's include it in the data for the path
  path(1:NPTS,its)=xg;
  path(NPTS+ip,its)=pg;


  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Step 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %let's get the next direction vector
  fullD = fulldf(xg,p,Dp,s0,sig0);
  w = ((RHS')/fullD)';
  %and normalise it
  w=w./norm(w,2);
  s0=w(1:NPTS);
  sig0=w(NPTS+1);

  %just re-label the variables so that (x0,p0) is the solution just found
  x0=xg;
  p0=pg;
  
  %Let's see if we've gone through a fold point (not very sophisticated
  %checking - we just look at whether the parameter direction has changed
  if (its > 2)
    folddetected = ((pg-path(NPTS+ip,its-1))*(path(NPTS+ip,its-1)-path(NPTS+ip,its-2)) < 0);
    if folddetected
        disp('=====================');
        disp(['Found fold near ',num2str(pg)]);
        disp('=====================');
        if FindFold
            approxk = path(1:NPTS,its) - path(1:NPTS,its-2);approxk = approxk/norm(approxk);
            foldPoints = [foldPoints ; startPoint+its approxk'];
        end
    end
  end

  
  if mod(its,140)==1,
      disp([num2str(floor(100*its/StepsAroundCurve)),' Percent complete']);
      disp(['Last parameter equals ',num2str(pg)]);
      disp(['Last no of Newton iterations is ',num2str(NewtonIts),' and dt = ',num2str(dt)]);
      disp(['Last nonlinear residual ',num2str(norm(F(xg,p),inf))]);
  end
  
end

foldPoints = foldPoints';

return