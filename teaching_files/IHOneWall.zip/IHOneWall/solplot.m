function solplot(path,f,step)

global Nx x dx

NPTS = Nx;
[N M] = size(path);

if nargin < 3
    step = 1;
end

if nargin < 2
    f = [];
end

subplot(1,2,1);
bifplot2(path,f);
bifplot2(path,f);

for j = 1:step:M
    subplot(1,2,2);
    v = path(1:NPTS,j);
    epsilon = path(NPTS+1,j);
    a = path(NPTS+2,j);
    b = path(NPTS+3,j);
    L = path(NPTS+4,j);
    fineplot(v,dx/10,L);axis tight;
%    ylabel(epsilon);
    xlabel(['a = ',num2str(a)]);
    ylabel('interface');
    set(gca,'fontsize',12);
    
    subplot(1,2,1);
    energy = integrate(path(1:Nx,j),[path(end-3,j) path(end-2,j) path(end-1,j) path(end,j)]);
    unplot;
    plot(a,energy,'ok','Markersize',10,'Linewidth',2);

    drawnow;
end
