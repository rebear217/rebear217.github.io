function V = Newton(v0,p)
%v0 is the initial guess, p are the parameters.
% Given an initial guess x at the parameters p, solve ||Fun(x,p)||<tol.

global x tol MaxNewtonIts

plotNow = 0;%set this to 1 to see the Newton iterations making progress

myerror = tol+1;
nsteps = 0;

disp('In Newton now');

if plotNow
    fig = gcf;
end
step = zeros(size(v0));

while (myerror > tol) && (nsteps <= MaxNewtonIts)
    RHS = F(v0,p);
    D = dfMatrix(v0,p);
    step = ((RHS')/D)';
    myerror = norm(step,inf)/norm(v0,inf);
    if plotNow
        plot(x,v0,x,psi(x,p(4)));   figure(fig);    xlabel(['Size of last Newton step ',num2str(myerror)]);
    end
    v0 = v0 - step;
    nsteps=nsteps+1;
end

if (myerror <= tol)
  V=v0;
  disp('================================================');
  disp(['Newton iteration converged, final step length ',num2str(norm(step,inf)),...
      ' using ',num2str(nsteps),' Newton steps']);
  res = norm(F(v0,p),inf);
  disp(['The corresponding residual is ',num2str(res)]);
  disp('================================================');
else
  disp('Convergence has not been obtained, returning vector anyway');
  V = v0;
end
