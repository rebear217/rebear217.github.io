global choice

choice = 0;

clc;

[p0,f0] = run([1e-3 -3 1 0]);
[p1,f1] = run([1e-3 -3 1 0.25]);
[p2,f2] = run([1e-3 -3 1 1]);[p2,f2] = run(p2,f2);
[p3,f3] = run([1e-4 -3 1 3.5]);
[p3,f3] = run(p3,f3);[p3,f3] = run(p3,f3);
[p3,f3] = run(p3,f3);[p3,f3] = run(p3,f3);

clc;
disp('Let us begin with the continuous transition in a smooth wedge');
pause;
solplot(p0(:,1:3:end));
disp('Transitions will appear for small corrugations: waiting to plot the solutions ...');
pause;
solplot(p1(:,1:3:end));
disp('Let us plot bifurcation diagrams: waiting ...');
pause;
close all;
bifplot(p0,f0);hold on;
bifplot(p1,f1);
disp('Figure 1: comparison of energies and film thickness with and without corrugations');
illustrate(p1,[64 93 145 191]);
disp('Figure 2: transition from state 1 to state 4 via vdW loops');
disp('A rougher wedge: waiting to plot the solutions ...');
pause;
close all;
solplot(p2(:,1:3:end));
disp('Re-plot some of the bifurcation diagrams comparing transitions in rough and smooth wedges: waiting ...');
pause;
close all;
bifplot(p0,f0);hold on;
bifplot(p1,f1);hold on;
bifplot(p2,f2);
disp('Now two sets of transitions appear for L large enough: waiting ...');
pause;
close all;
bifplot(p3,f3);
disp('Plot the solutions along this branch: waiting ...');
pause;
close all;
solplot(p3(:,1:3:end));
