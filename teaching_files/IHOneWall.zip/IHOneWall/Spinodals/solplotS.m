function solplotS(fpath)

global x Nx dx A

[n m] = size(fpath);

fstep = dx/10;
fx = -A:fstep:A;

Ls = fpath(2*Nx + 1,:);
epsilons = fpath(2*Nx+2,:);
as = fpath(2*Nx+3,:);
bs = fpath(2*Nx+4,:);


NPTS = Nx;

for j = 1:m
    v = fpath(1:Nx,j);
    k = fpath(Nx+1:2*Nx,j);
    L = fpath(2*Nx+1,j);

    fk = interp1(x,k,fx,'cubic');
    
    epsilon = fpath(2*Nx+2,j);
    a = fpath(2*Nx+3,j);
    b = fpath(2*Nx+4,j);

    subplot(1,2,1);fineplot(v,fstep,L);axis tight;
    xlabel('x');ylabel('solution');
    subplot(1,2,2);
    plot(fx,fk,'-b');axis tight;
    xlabel('x');ylabel('eigensolution');
    drawnow;
end
