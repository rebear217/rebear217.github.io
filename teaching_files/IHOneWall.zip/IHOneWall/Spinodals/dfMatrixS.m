function D = dfMatrixS(V,p)

global Nx D2x x

eps = p(1);
a = p(2);
b = p(3);

v = V(1:Nx);
k = V(Nx+1:2*Nx);
L = V(end);

p = [eps a b];

D11 = eps*D2x - diag(Wpp(v-psi(x,L),p));
D12 = zeros(Nx,Nx);
D13 = Wpp(v-psi(x,L),p).*psiL(x,L);

D21 = diag((-Wppp(v-psi(x,L),p)).*k);
%D22 = eps*D2x - diag(Wpp(v-psi(x,L),p));
%D22 = D11;
D23 = (Wppp(v-psi(x,L),p).*psiL(x,L)).*k;

D31 = zeros(1,Nx);
D32 = 2*k';
D33 = 0;

D = [D11 D12 D13; D21 D11 D23 ; D31 D32 D33];

end