function sPlot2(fpath)

global x Nx dx

[n m] = size(fpath);
energy = zeros(1,m);
itgl = energy;
Vnorms = max(abs(fpath(1:Nx,:)));
Knorms = max(abs(fpath(Nx+1:2*Nx,:)));

Ls = fpath(2*Nx + 1,:);
epsilons = fpath(2*Nx+2,:);
as = fpath(2*Nx+3,:);
bs = fpath(2*Nx+4,:);

for j = 1:m
    [energy(j),itgl(j)] = integrate(fpath(1:Nx,j),[fpath(end-2,j) fpath(end-1,j) fpath(end,j) fpath(2*Nx+1,j)]);
end

%subplot(1,3,1);hold on;
%plot(as,energy,'-k');
%ylabel('energy');
%xlabel('a');
%subplot(1,3,2);hold on;
%plot(Ls,energy,'-b');
%ylabel('energy');
%xlabel('L');
%subplot(1,3,3);
hold on;
plot(as,Ls,'-b','Linewidth',1);
ylabel('L');
xlabel('a');
axis tight;
