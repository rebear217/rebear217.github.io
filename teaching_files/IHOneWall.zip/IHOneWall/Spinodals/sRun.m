function Vpath = sRun(p,folds,pos)

global Nx x stol MaxNewtonIts dt dtMin dtMax StepsAroundCurve

stol = 1e-7;
StepsAroundCurve = 100;
MaxNewtonIts = 1000;
phaseParam = 2;
direction = 1;

dt = 0.01;dtMax = 10.4;dtMin = 0.05;

if nargin > 1
    [n m] = size(folds);
    if nargin == 2
        pos = 1;
        disp('** Assuming the first fold point found **');
    end

    j = folds(1,pos);
    k = folds(2:end,pos);k = k/norm(k);%k = k/sum(k);

    params = p(Nx + 1:Nx + 4,j);
    v = p(1:Nx,j);
    %k = k/sum(k.*v);
    eps = params(1); a = params(2); b = params(3); L = params(4);

    V = [v ; k ; L];
    disp(['In inf-norm we have initial spinodal residual : ',num2str(norm(spinodalF(V,[eps a b]),inf))]);

    V = sNewton(V,[eps a b]);
    dt = dt * direction;
    [Vpath,returnerror] = scont(V,[eps a b],phaseParam);
elseif nargin == 1
    V = p(1:2*Nx + 1,end);
    eps = p(2*Nx + 2,end);
    a = p(2*Nx + 3,end);
    b = p(2*Nx + 4,end);
    [n m] = size(p);
    if (m > 1)
        direction = sign(p(2*Nx + 1 + phaseParam,end) - p(2*Nx + 1 + phaseParam,end-1));
    end
    
    dt = dt * direction;
    
    [Vpath,returnerror] = scont(V,[eps a b],phaseParam);
    Vpath = [p Vpath];
end
