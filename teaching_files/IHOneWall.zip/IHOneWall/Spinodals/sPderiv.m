function pd=sPderiv(V,p,i)

% Numerically calculates the partial derivative of 
% Fun(x,p) wrt the i-th entry in p

global x Nx

    h=1e-5;
    ei=zeros(size(p));
    ei(i)=h;
    pd1=spinodalF(V,p+ei);
    pd2=spinodalF(V,p-ei);

    pd=(pd1-pd2)/h/2;
    
return

%this code has an error in it
%if i == 2
%    eps = p(1);
%    a = p(2);
%    b = p(3);
%
%    v = V(1:Nx);
%    k = V(Nx+1:2*Nx);
%    L = V(2*Nx+1);
%
%    p = [eps a b];
%
%    vout = -Wpa(v-psi(x,L),p);
%    kout = -Wppa(v-psi(x,L),p).*k;
%    aout = 0;
%
%    pd = [vout ; kout ; aout];
%
%end