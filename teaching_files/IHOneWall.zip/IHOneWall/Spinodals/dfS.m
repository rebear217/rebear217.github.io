function D=dfS(k,V,p)

global Nx

ep = 1e-8;
n=2*Nx+1;

if norm(k) == 0
    D=zeros(n,1);
    return
end
ep = ep/norm(k);
if norm(V) > 0
    ep=ep*norm(V);
end
D1 = spinodalF(V+ep*k,p);
D2 = spinodalF(V-ep*k,p);
D = (D1-D2)/ep/2;
return