function Vout = spinodalF(V,p)

global D2x x Nx dx e

eps = p(1);
a = p(2);
b = p(3);


v = V(1:Nx);
k = V(Nx+1:2*Nx);
L = V(2*Nx+1);

p = [eps a b];

vout = eps*D2x*v -Wp(v-psi(x,L),p);
kout = eps*D2x*k -(Wpp(v-psi(x,L),p)).*k;
aout = norm(k)^2 - 1;

Vout = [vout ; kout ; aout];
end