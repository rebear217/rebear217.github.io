function V = sNewton(v,p)

global x stol MaxNewtonIts Nx

% Given an initial guess x at the parameters p, solve ||Fun(x,p)-0||<tol.

v0 = v;

myerror = stol+1;
nsteps = 0;

disp('Now in Spinodal Newton ... ');

%fig =figure;
step = zeros(size(v));

while (myerror > stol) && (nsteps <= MaxNewtonIts)
    RHS = spinodalF(v0,p);
    D = dfMatrixS(v0,p);
    step = D\RHS;
    myerror = norm(step,inf)/norm(v0,inf);
    v0 = v0 - step;
    nsteps=nsteps+1;
%    figure(fig);    plotyy(x,v0(1:Nx),x,v0(Nx+1:2*Nx));
%    xlabel(['Size of last Newton step ',num2str(myerror)]);
%    title(['L = ',num2str(v0(end))]);    drawnow;
end

if (myerror <= stol)
  V=v0;
  disp('=========================================================================');
  disp(['Newton iteration converged, final step length ',num2str(norm(step,inf)),...
      ' using ',num2str(nsteps),' Newton steps']);
  res = norm(spinodalF(v0,p),inf);
  disp(['The corresponding residual is ',num2str(res)]);
  disp(['Parameters are [eps  a  b] = [',num2str(p),' ]']);
  disp('=========================================================================');
else
  disp('Convergence has not been obtained, returning vector anyway');
  V = v0;
end
