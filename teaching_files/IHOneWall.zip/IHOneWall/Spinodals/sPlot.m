function sPlot(fpath)

global x Nx dx A

[n m] = size(fpath);
energy = zeros(1,m);
itgl = energy;
itglpsi = energy;
Vnorms = max(abs(fpath(1:Nx,:)));
Knorms = max(abs(fpath(Nx+1:2*Nx,:)));

Ls = fpath(2*Nx + 1,:);
epsilons = fpath(2*Nx+2,:);
as = fpath(2*Nx+3,:);
bs = fpath(2*Nx+4,:);

for j = 1:m
    [energy(j),itgl(j)] = integrate(fpath(1:Nx,j),[fpath(end-2,j) fpath(end-1,j) fpath(end,j) fpath(2*Nx+1,j)]);
    itglpsi(j) = sum(psi(x,Ls(j)))*dx;
end

%fig = figure;

%subplot(1,2,1);hold on;
%plot(as,energy,'-b');
%ylabel('energy');
%xlabel('a');
%subplot(1,2,2);hold on;
plot(as,(itgl-itglpsi)/(2*A),'--b','Linewidth',2);
set(gca,'fontsize',12);
ylabel('mean interface height');
xlabel('a');

%title('Superimposed spinodal curves');
%subplot(1,3,3);hold on;
%plot(as,Ls,'-r');
%ylabel('L');
%xlabel('a');
%axis tight;
