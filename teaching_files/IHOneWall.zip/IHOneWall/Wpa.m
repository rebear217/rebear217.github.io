function wpa = Wpa(v,p)
    a = p(2);
    b = p(3);
%    wpa = -2./v.^3;
    wpa = -exp(-v);

end