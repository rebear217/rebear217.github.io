global choice

choice = 2;
clc;

[p0,f0] = run([1e-3 -1.5 1 1]);
[p1,f1] = run([1e-3 -1.5 1 3]);
[p2,f2] = run([1e-3 -1.5 1 5]);
bifplot(p0,f0);
bifplot(p1,f1);
bifplot(p2,f2);
placeplotBinodals(p2,[150 534]);

figure(1);
subplot(1,2,1);
axis([-0.45 0.1 -0.07 0.01]);
subplot(1,2,2);
axis([-0.8 0.03 1 12]);

illustrate(p2,[150 534]);
subplot(1,3,1);
axis([-0.43 -0.3 -0.07 0]);

