function bifplot(path,folds)

global Nx dx A x

NPTS = Nx;
[N M] = size(path);

if nargin == 1
    folds = [];
end

energy = zeros(1,M);itgl = energy; Zenergy = energy;
norms = max(abs(path(1:NPTS,:)));%norms = dx*(sum(path(1:NPTS,:).^2)).^(1/2);
for j = 1:M
    [energy(j),itgl(j)] = integrate(path(1:NPTS,j),[path(end-3,j) path(end-2,j) path(end-1,j) path(end,j)]);
    Zenergy(j) = integrate(zeros(NPTS,1),[path(end-3,j) path(end-2,j) path(end-1,j) path(end,j)]);
end
epsilons = path(NPTS+1,:);
as = path(NPTS+2,:);
bs = path(NPTS+3,:);
Ls = path(NPTS+4,:);
%provided L doesn't change across the run:
itlpsi = sum(psi(x,Ls(1)))*dx;
%if L does change, this won't work
if not(Ls(1) == Ls(2))
    disp('warning - this plot may be incorrect');
end

subplot(1,2,1);hold on;
plot(as,energy,'-b','Linewidth',1);%plot(as,Zenergy,'-b');
%plot(as,energy,'.g');
set(gca,'fontsize',12);
ylabel('energy');
xlabel('a');
%subplot(1,3,2);hold on;
%plot(as,norms,'-b');
%ylabel('L^\infty norm');
%xlabel('a');
subplot(1,2,2);
set(gca,'fontsize',12);
hold on;
plot(as,(itgl-itlpsi)/(2*A),'-r','Linewidth',1);
ylabel('mean interface height');
xlabel('a');
axis tight;

if not(isempty(folds))
    F = folds(1,:);
    for j = 1:length(F)
        subplot(1,2,1);
        hold on;
        plot(as(F(j)),energy(F(j)),'.r','Markersize',15);
        subplot(1,2,2);
        hold on;
        plot(as(F(j)),(itgl(F(j))-itlpsi)/(2*A),'.b','Markersize',15);
    end
end
