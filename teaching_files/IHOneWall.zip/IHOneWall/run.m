function [path,foldPoints] = run(path,oldfolds)

global dtMax dtMin StepsAroundCurve dt inittol A Nx D2x D x ...
    dx conttol tol MaxNewtonIts parameters l u choice

%choice = 2;%make this zero for the 'generic' choice of psi

A = pi/2; Nx = 100;

%1 for epsilon and 2 for a
parameters = { 'epsilon' , 'a' , 'b', 'L' };
parameter = 2;
findfold = 1;

disp('Continuing in parameter : ');
disp(parameters(parameter));

if nargin == 1
        oldfolds = [];
end

if length(path) == length(parameters)
    epsilon = path(1);
    a = path(2);
    b = path(3);
    L = path(4);
    path = [];
    direction = 1;%the direction of the parameter in which to look initially (an orientation)
    M = 0;
else
    [N M] = size(path);
    if (Nx~= N-4)
        error('Path dimensions don''t match run dimensions');
    end
    v = path(1:N-4,end);
    epsilon = path(N-3,end);
    a = path(N-2,end);
    b = path(N-1,end);
    L = path(N,end);

    %the intial orientation of the direction of Gamma in the parameter used
    if (M > 1),
        direction = sign(path(N-length(parameters) + parameter,end) - path(N-length(parameters) + parameter,end-1));
    else
        direction = -1;%otherwise decrease the parameter along the curve
    end
end

%data we need to measure convergence of the Newton iterations
inittol = 0.05;
tol = 1e-11; conttol = 1e-11; MaxNewtonIts = 500;

%how much of the curve (Gamma) do we want?
StepsAroundCurve = 1000;
%what are the PAL parameters to begin with?
dt = direction*0.1; dtMax = 2; dtMin = 0.01;

% x variable in [-A,A], Fourier:
%%%%%%%%%%%%%%%%%%
dx = 2*A/Nx;
x = -A+dx*(1:Nx)';
D2x = (pi/A)^2*toeplitz([-1/(3*(dx/A)^2)-1/6 .5*(-1).^(2:Nx)./sin((pi*dx/A)*(1:Nx-1)/2).^2]);
column = [0 .5*(-1).^(1:Nx-1).*cot((1:Nx-1)*dx/2)]';
D = toeplitz(column,column([1 Nx:-1:2]));
%%%%%%%%%%%%%%%%%%

% Grid and initial data: use a Newton method with initial guess as the substrate plus a little bit
if isempty(path)
    v = psi(x,L) + 0.1;
    v = Newton(v,[epsilon a b L]);
end

%all the work is done inside the cont.m file, this is the PAL "engine":
[newpath,foldPoints,errors]=cont(v,[epsilon a b L],parameter,findfold,M);
foldPoints = [oldfolds foldPoints];

%if not(errors)
    path = [path newpath];
    v0 = newpath(1:end-4,end);
    epsilon = newpath(end-3,end);
    a = newpath(end-2,end);
    b = newpath(end-1,end);
    L = newpath(end,end);


disp('--------');
disp('Finished');

end
