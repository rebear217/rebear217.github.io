global choice

choice = 4;
clc;

[p0,f0] = run([1e-3 -1.5 1 1]);
[p1,f1] = run([1e-3 -1.5 1 3]);
[p2,f2] = run([1e-3 -2 1 6]);
[p2,f2] = run(p2,f2);
bifplot(p0,f0);
bifplot(p1,f1);
bifplot(p2,f2);
placeplotBinodals(p2,[875 384]);
placeplotBinodals(p2,[41 363]);
figure(1);
subplot(1,2,1);
axis([-2 0.1 -1.2 0.01]);
subplot(1,2,2);
axis([-2.5 0.2 -0.3 13]);

illustrate(p2,[875 384]);
subplot(1,3,1);
axis([-1.37 -1.3 -0.47 -0.38]);

illustrate(p2,[41 363]);
subplot(1,3,1);
axis([-1.42 -1.36 -0.65 -0.4]);
