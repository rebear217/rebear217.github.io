function p = fullprecon(l,u,r,q,b)

p = zeros(size(b));
m = length(b);n = m-1;

B = b(1:n);
B = LUsubs(l,u,r,q,B);
p(m) = b(m);
p(1:n) = B;


return

