function illustrate(p,positions)

global Nx dx A x

[N M] = size(p);
energy = zeros(1,M);itgl = energy;

fig = figure;

K = length(positions);

subplot(1,K+1,1);
bifplot2(p);%bifplot(p);

for j = 1:K
    figure(fig);
    P = p(:,positions(j));
    subplot(1,K+1,1);
    L = P(end);
    [energy,itgl] = integrate(P(1:Nx),[P(end-3) P(end-2) P(end-1) P(end)]);
    itglpsi = sum(psi(x,L))*dx;
    plot(P(end-2),energy,'.r','Markersize',10);hold on;
    text(P(end-2),energy,num2str(j));
%    plot(P(end-2),(itgl-itglpsi)/(2*A),'.b','Markersize',20);hold on;
%    text(P(end-2),(itgl-itglpsi)/(2*A),num2str(j));
    axis tight;
    hold on;
    subplot(1,K+1,j+1);
    solplot2(P);
%    axis([-A A min(psi(x,P(end))) 0]);
    title(num2str(j));
end

