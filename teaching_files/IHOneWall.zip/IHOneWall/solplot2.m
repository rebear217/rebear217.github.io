function solplot2(path,f,step)

global Nx x dx

NPTS = Nx;
[N M] = size(path);

if nargin < 3
    step = 1;
end

if nargin < 2
    f = [];
end

for j = 1:step:M
    v = path(1:NPTS,j);
    epsilon = path(NPTS+1,j);
    a = path(NPTS+2,j);
    b = path(NPTS+3,j);
    L = path(NPTS+4,j);
    fineplot(v,dx/10,L);axis tight;
%    ylabel(epsilon);
    xlabel(['a = ',num2str(a)]);
    ylabel('interface');
    set(gca,'fontsize',12);
    
    drawnow;
end
