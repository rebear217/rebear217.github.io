function D = dfMatrix(v,p)

global D2x x

L = p(4);
eps = p(1);

D = eps*D2x - diag(Wpp(v-psi(x,L),p));
end