function bifplot3(p,folds)

global Nx A dx x

if nargin == 1
    folds = [];
end

[N M] = size(p);

energy = zeros(1,M);itgl = energy;
for j = 1:M
    [energy(j),itgl(j)] = integrate(p(1:Nx,j),[p(end-3,j) p(end-2,j) p(end-1,j) p(end,j)]);
end
epsilons = p(Nx+1,:);
as = p(Nx+2,:);
bs = p(Nx+3,:);

%if the variable L does not change within a run then:
itglpsi = sum(psi(x,p(end,1)))*dx;

plot(as,(itgl-itglpsi)/(2*A),'-r','Linewidth',2);hold on;
set(gca,'fontsize',12);
xlabel('a');
ylabel('interface height');
hold on;axis tight;

if not(isempty(folds))
    F = folds(1,:);
    for j = 1:length(F)
%        subplot(1,2,1);
        hold on;
%        subplot(1,2,2);
%        hold on;
        plot(as(F(j)),(itgl(F(j))-itglpsi)/(2*A),'.b','Markersize',20);
    end
end
