function wpp = Wpp(v,p)
    a = p(2);
    b = p(3);
%    wpp = 6*a./v.^4 + 12*b./v.^5;
    wpp = a*exp(-v) + 4*b*exp(-2*v);
%    wpp = a*exp(-v) - 4*b*exp(-2*v) + 9*exp(-3*v);
%    wpp = exp(-v);

end