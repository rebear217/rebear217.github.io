function D = bfulldf(V,p,Dp,s0,sig0)

DV = dfMatrixB(V,p);
D = [DV Dp ; s0' sig0];

end