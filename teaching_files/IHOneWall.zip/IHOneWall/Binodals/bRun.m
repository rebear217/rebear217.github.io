function Bpath = bRun(p,j1,j2)

global Nx x stol MaxNewtonIts dt dtMin dtMax StepsAroundCurve

stol = 1e-8;
StepsAroundCurve = 100;
MaxNewtonIts = 1000;
phaseParam = 2;
direction = 1;

dt = 0.1;dtMax = 0.4;dtMin = 0.01;

if nargin > 1
    [B,P] = binodalPrepare(p,j1,j2);
    eps = P(1); a = P(2); b = P(3); L = B(end);
    B = bNewton(B,[eps a b]);
    dt = dt * direction;
    [Bpath,returnerror] = bcont(B,[eps a b],phaseParam);
    Bpath = [[B ;eps ;a ;b] Bpath];
elseif nargin == 1
    B = p(1:2*Nx + 1,end);
    eps = p(2*Nx + 2,end);
    a = p(2*Nx + 3,end);
    b = p(2*Nx + 4,end);
    [n m] = size(p);
    if (m > 1)
        direction = sign(p(2*Nx + 1 + phaseParam,end) - p(2*Nx + 1 + phaseParam,end-1));
    end
    
    dt = dt * direction;
    
    [Bpath,returnerror] = bcont(B,[eps a b],phaseParam);
    Bpath = [p Bpath];
end
