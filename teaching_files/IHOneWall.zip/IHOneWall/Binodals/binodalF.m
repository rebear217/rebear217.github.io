function Vout = binodalF(V,p)

global Nx

p1 = V(1:Nx);
p2 = V(Nx+1:2*Nx);
L = V(end);

eps = p(1);
a = p(2);
b = p(3);

energy1 = integrate(p1,[eps a b L]);energy2 = integrate(p2,[eps a b L]);
p1out = F(p1,[eps a b L]);
p2out = F(p2,[eps a b L]);

Vout = [p1out ; p2out ; energy1 - energy2];