function B = findBinodals(p,tolerance,cutoff)

if nargin == 1
    tolerance = 0.0001;
    cutoff = 0.4;
end

global Nx

[n m] = size(p);

energies = zeros(1,m);
as = zeros(1,m);epss = zeros(1,m);bs = zeros(1,m); Ls = zeros(1,m);

for j = 1:m
    thisParams = p(Nx+1:end,j);
    thisSolution = p(1:Nx,j);
    epss(j) = thisParams(1); as(j) = thisParams(2); bs(j) = thisParams(3); Ls(j) = thisParams(4);
    energies(j) = integrate(thisSolution,thisParams);
end

Ps = zeros(m,m); Ps = sparse(Ps);

for j = 1:floor((m+1)/2)
    G = find(abs(as - as(j)) < tolerance);
    F = find(abs(energies(G) - energies(j)) < tolerance);
    if (length(G(F)) > 1)
        Ps(j,G(F)) = abs(G(F) - j);
    end
end

M = cutoff*max(max(Ps));
Ps = Ps .* (Ps > M);
[rows,cols,vals] = find(Ps);
B = [rows cols];

bifplot(p);
placeplotBinodals(p,B);

return