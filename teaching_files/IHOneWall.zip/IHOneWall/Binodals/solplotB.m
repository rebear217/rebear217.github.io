function solplotB(bpath)

global x Nx dx A

[n m] = size(bpath);

fstep = dx/10;
fx = -A:fstep:A;

Ls = bpath(2*Nx + 1,:);
epsilons = bpath(2*Nx+2,:);
as = bpath(2*Nx+3,:);
bs = bpath(2*Nx+4,:);

NPTS = Nx;

    subplot(1,2,1);
    bPlot(bpath);
    bPlot(bpath);

for j = 1:m
    v1 = bpath(1:Nx,j);
    v2 = bpath(Nx+1:2*Nx,j);
    L = bpath(2*Nx+1,j);
    
    epsilon = bpath(2*Nx+2,j);
    a = bpath(2*Nx+3,j);
    b = bpath(2*Nx+4,j);


    subplot(1,2,2);
    fineplot(v1,fstep,L);axis tight;hold on;
    set(gca,'Fontsize',12);
    xlabel('x');ylabel('first solution');
    fineplot(v2,fstep,L,'-b');axis tight;
    xlabel('x');ylabel('second solution');
    title(['(a,L) = (',num2str(a),' , ',num2str(L),')']);
    
    subplot(1,2,1);
    unplot;
    [energy,itgl] = integrate(bpath(1:Nx,j),[bpath(end-2,j) bpath(end-1,j) bpath(end,j) bpath(2*Nx+1,j)]);
    plot(a,energy,'or','Markersize',10,'Linewidth',2);
    drawnow;
    
    
end
