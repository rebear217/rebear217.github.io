function [b,P] = binodalPrepare(inP,j1,j2)

global Nx

p1 = inP(:,j1);
p2 = inP(:,j2);

b = zeros(2*Nx+1,1);

b(1:Nx) = p1(1:Nx);%sol1
b(Nx+1:2*Nx) = p2(1:Nx);%sol2
p = p1(Nx+1:end);
b(end) = p(4);%L
P = p(1:3);% eps a b

disp(['As a check, this should be small : ',num2str(norm(p1(Nx+1:end) - p2(Nx+1:end)))]);
disp(['this is the nonlinear residual inf norm : ',num2str(norm(binodalF(b,P),inf))]);
