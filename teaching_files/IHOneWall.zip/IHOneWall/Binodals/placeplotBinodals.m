function placeplotBinodals(p,B)

global Nx A x dx

[n m] = size(B);

fig = gcf;

for j = 1:n
    pos1 = B(j,1); pos2 = B(j,2);
    a1 = p(Nx + 2,pos1); a2 = p(Nx + 2,pos2);
    L1 = p(Nx + 4,pos1); L2 = p(Nx + 4,pos2);
    sol1 = p(1:Nx,pos1); sol2 = p(1:Nx,pos2);
    [energy1,inte1] = integrate(sol1,p(Nx+1:end,pos1));
    [energy2,inte2] = integrate(sol2,p(Nx+1:end,pos2));
    itglpsi1 = sum(psi(x,L1))*dx;
    itglpsi2 = sum(psi(x,L2))*dx;

    subplot(1,2,1);
    hold on; plot(a1,energy1,'.g','Markersize',20);hold on; plot(a2,energy2,'.g','Markersize',20);
    subplot(1,2,2); hold on; plot(a1,(inte1-itglpsi1)/(2*A),'.g','Markersize',20);hold on; plot(a2,(inte2-itglpsi2)/(2*A),'.g','Markersize',20);
end