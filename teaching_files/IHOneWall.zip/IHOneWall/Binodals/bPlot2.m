function bPlot2(bpath)

global x Nx dx

[n m] = size(bpath);
energy = zeros(1,m);
itgl = energy;
V1norms = max(abs(bpath(1:Nx,:)));
V2norms = max(abs(bpath(Nx+1:2*Nx,:)));

Ls = bpath(2*Nx + 1,:);
epsilons = bpath(2*Nx+2,:);
as = bpath(2*Nx+3,:);
bs = bpath(2*Nx+4,:);

for j = 1:m
    [energy(j),itgl(j)] = integrate(bpath(1:Nx,j),[bpath(end-2,j) bpath(end-1,j) bpath(end,j) bpath(2*Nx+1,j)]);
    psiIntls = sum(psi(x,Ls(j)))*dx;
end

%subplot(1,3,1);hold on;
%plot(as,energy,'-r','Linewidth',2);
%ylabel('energy');
%xlabel('a');
%subplot(1,3,2);hold on;
%plot(Ls,energy,'-k','Linewidth',2);
%ylabel('energy');
%xlabel('L');
%subplot(1,3,3);
hold on;
plot(as,Ls,'-k','Linewidth',2);
set(gca,'fontsize',14);
ylabel('L');
xlabel('a');
axis tight;
