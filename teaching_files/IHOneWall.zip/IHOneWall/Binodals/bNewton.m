function B = bNewton(B,p)

global x stol MaxNewtonIts Nx

% Given an initial guess x at the parameters p, solve ||Fun(x,p)-0||<tol.

v0 = B;

myerror = stol+1;
nsteps = 0;

disp('Now in Binodal Newton ... ');

%fig = figure;
step = zeros(size(B));

while (myerror > stol) && (nsteps <= MaxNewtonIts)
    RHS = binodalF(v0,p);
    D = dfMatrixB(v0,p);
    step = D\RHS;
    myerror = norm(step,inf)/norm(v0,inf);
    v0 = v0 - step;
    nsteps=nsteps+1;
%    figure(fig);
%    plotyy(x,v0(1:Nx),x,v0(Nx+1:2*Nx));
%    xlabel(['Size of last Newton step ',num2str(myerror)]);
%    title(['L = ',num2str(v0(end))]);
%    drawnow;
end


B=v0;
if (myerror <= stol)
  disp('=========================================================================');
  disp(['Newton iteration converged, final step length ',num2str(norm(step,inf)),...
      ' using ',num2str(nsteps),' Newton steps']);
  res = norm(binodalF(v0,p),inf);
  disp(['The corresponding residual is ',num2str(res)]);
  disp(['Parameters are [eps  a  b] = [',num2str(p),' ]']);
  disp(['L is ',num2str(B(end)),' and energies are ',num2str(integrate(B(1:Nx),[p B(end)])),' and ',num2str(integrate(B(Nx+1:2*Nx),[p B(end)]))]);
  disp('=========================================================================');
else
  disp('Convergence has not been obtained, returning vector anyway');
end
