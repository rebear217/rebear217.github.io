function bPlot3(bpath)

global x Nx dx A

[n m] = size(bpath);
energy = zeros(1,m);
itgl = energy;
b1norms = max(abs(bpath(1:Nx,:)));
b2norms = max(abs(bpath(Nx+1:2*Nx,:)));

Ls = bpath(2*Nx + 1,:);
epsilons = bpath(2*Nx+2,:);
as = bpath(2*Nx+3,:);
bs = bpath(2*Nx+4,:);

for j = 1:m
    [energy(j),itgl(j)] = integrate(bpath(1:Nx,j),[bpath(end-2,j) bpath(end-1,j) bpath(end,j) bpath(2*Nx+1,j)]);
    [energy2(j),itgl2(j)] = integrate(bpath(Nx+1:2*Nx,j),[bpath(end-2,j) bpath(end-1,j) bpath(end,j) bpath(2*Nx+1,j)]);    
    psiIntls = sum(psi(x,Ls(j)))*dx;
end

%fig = figure;

plot((itgl-psiIntls)/(2*A),as,'-k','Linewidth',2);
hold on;
plot((itgl2-psiIntls)/(2*A),as,'-k','Linewidth',2);
set(gca,'fontsize',14);
ylabel('a');
xlabel('mean interface height');