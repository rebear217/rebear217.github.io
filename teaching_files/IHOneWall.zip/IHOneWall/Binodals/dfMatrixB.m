function D = dfMatrixB(V,p)

global Nx D2x x dx

eps = p(1);
a = p(2);
b = p(3);

v1 = V(1:Nx);
v2 = V(Nx+1:2*Nx);
L = V(end);

p = [eps a b];

D11 = eps*D2x - diag(Wpp(v1-psi(x,L),p));
D12 = zeros(Nx,Nx);
D13 = Wpp(v1-psi(x,L),p).*psiL(x,L);

D21 = zeros(Nx,Nx);
D22 = eps*D2x - diag(Wpp(v2-psi(x,L),p));
D23 = Wpp(v2-psi(x,L),p).*psiL(x,L);

dLEv1 = dx*sum(-Wp(v1-psi(x,L),p).*psiL(x,L));
dLEv2 = dx*sum(-Wp(v2-psi(x,L),p).*psiL(x,L));

D31 = dx*(-eps*D2x*v1 + Wp(v1-psi(x,L),p));
D32 = -dx*(-eps*D2x*v2 + Wp(v2-psi(x,L),p));
D33 = dLEv1 - dLEv2;

D = [D11 D12 D13; D21 D22 D23 ; D31' D32' D33];

end