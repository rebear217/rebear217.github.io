function fineplot(v,fstep,L,style)

global A x Nx choice

if nargin == 1;
    fstep = 0.05;
end

if nargin < 4
    style = '-k';
end

fx = -A:fstep:A;
v = [v(Nx/2+1:end) ; v(1:(Nx/2))];

fv = interp1(x,v,fx,'cubic');

psix = psi(x,L);
psix = [psix(Nx/2+1:end) ; psix(1:(Nx/2))];

psix = interp1(x,psix,fx,'cubic');
%plot(fx,psix,'-r'); hold on;
%plot(fx,fv,'-k','Linewidth',2);hold off;axis tight; 

plot(fx,psix,'-r'); hold on;
plot(fx,fv,style,'Linewidth',2);hold off;axis tight; 

end