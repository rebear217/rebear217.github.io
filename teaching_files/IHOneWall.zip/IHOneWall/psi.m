function ps = psi(x,L)

global A choice

if choice == 0

%ps = L*cos(2*x);%plenty of vdW loops;phi = -psi; keep L near 5?
%ps = -10 + L*cos(2*x);%not so many vdW loops;phi = -psi; keep L near 7

%ps = L*cos(3*x);%two clear vdW loops;phi = -psi; keep L near 9?
%ps = -20 + 5*cos(3*x);%phi = -psi;

%thimble
%ps = -20 + L*cos(4*x);%phi = -psi;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%shark's mouth
%ps = -20 + 8*abs(x) + L*cos(20*x);%phi = -phi;%keep the cos parameter in 2.9 to 3.2 onwards...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%thimblecusp
%Nice one to illustrate phase transitions, only a couple of spinodals
%ps = -20 + L*cos(3*x);%two clear vdW loops;phi = -psi; %start L near 7
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%ps = -40 + L*abs(4*x) + 4*cos(20*x);%phi = -phi;%L=5;

% wobbly wedge
%eps = 0.0;
%q = pi/A;
%ps = 20*abs(x) + L*cos(20*x);%phi = -phi;%keep the cos parameter in 2.5 to 4?L = 5.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%ps = 1.25*cos(x) + L*cos(6*x);%[p,f] = run([1e-3 -3 1 5]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ps = 10*cos(2*x) + L*cos(20*x);%[p,f] = run([1e-3 -3 1 5]);

%ps = L*cos(2*x);

else
    
    switch choice
        case 1
            ps = L*abs(x);
        case 2
            ps = L*cos(2*x);
        case 3
            ps = 10*cos(2*x) + L*cos(20*x);
        case 4
            ps = 1.25*cos(x) + L*cos(6*x);
        case 5
            ps = 20*abs(x) + L*cos(20*x);
    end

end