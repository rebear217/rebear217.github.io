function D = fulldf(x,p,Dp,s0,sig0)

%this is the matrix defined in steps 3 and 4 of the PAL methodology

D = [dfMatrix(x,p) s0 ;
    Dp' sig0];

end