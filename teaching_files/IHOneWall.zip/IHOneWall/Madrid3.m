global choice

choice = 1;
clc;

[p0,f0] = run([1e-3 -2 1 1]);
[p1,f1] = run([1e-3 -2 1 5]);
[p2,f2] = run([1e-3 -2 1 8]);
[p3,f3] = run([1e-3 -2 1 11]);
[p3,f3] = run(p3,f3);
bifplot(p0,f0);
bifplot(p1,f1);
bifplot(p2,f2);
bifplot(p3,f3);