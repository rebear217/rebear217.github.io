function wppa = Wppa(v,p)
    a = p(2);
    b = p(3);
%    wppa = 6./v.^4;
    wppa = exp(-v);

end