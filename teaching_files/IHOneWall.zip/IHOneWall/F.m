function vout = F(v,p)

global D2x x

L = p(4);
eps = p(1);

vout = eps*D2x*v - Wp(v-psi(x,L),p);

end