function [energy,itgl] = integrate(u,p)

global D2x x dx

eps = p(1);
a = p(2);
b = p(3);
L = p(4);
itgl = sum(u)*dx;
%energy = dx*sum(-eps*u.*(D2x*u)/2 + W(u-psi(x,L),[eps a b L]) + W(phi(x,L)-u,[eps a b L]));
energy = dx*sum(-eps*u.*(D2x*u)/2 + W(u-psi(x,L),[eps a b L]));