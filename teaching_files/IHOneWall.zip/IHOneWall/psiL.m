function pL = psiL(x,L)

global choice

if choice == 0
    del = 1e-6;
    pL = (psi(x,L+del) - psi(x,L-del))/del/2;
else    
    switch choice
        case 1
            pL = abs(x);
        case 2
            pL = cos(2*x);
        case 3
            pL = cos(20*x);
        case 4
            pL = cos(6*x);
        case 5
            pL = cos(20*x);

    end

end