function beginMadrid(dft)

clc
cd G:\reb\maTLAB\Madrid\
P = genpath(cd);
P = rmpath(P);

switch dft
    
    case 1

        cd IHOneWall
        
    case 2

        cd Evans86
        
end

P = genpath(cd);
addpath(P);

close all
clear all