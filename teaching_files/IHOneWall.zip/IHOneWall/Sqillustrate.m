function Sqillustrate(p,positions)

global Nx dx A x

[N M] = size(p);
energy = zeros(1,M);itgl = energy;

fig = figure;

%subplot(2,3,1);
%bifplot2(p);

for j = 1:9
    figure(fig);
    P = p(:,positions(j));
%    subplot(3,3,1);
%    [energy,itgl] = integrate(P(1:Nx),[P(end-3) P(end-2) P(end-1) P(end)]);
%    plot(P(end-2),energy,'.r');hold on;
%    text(P(end-2),energy,num2str(j));
%    axis tight;
%    hold on;
    subplot(3,3,j);
    solplot(P);
    title(num2str(j));
    xlabel('');
    axis([-A A min(psi(x,P(end))) max(psi(x,P(end)))*1.2 ]);

%    str = [num2str(j),' : a = ',num2str(P(end-2))];
%    ylabel(str);
end