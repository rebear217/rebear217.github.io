function [energy,adsorption,integral,entropy,mu] = measures(q,p)

global dx space2 Weights space

L = p(3);
beta = p(2);
mu = p(1);

rho = 2*q/L/beta;
z = exp(mu*beta);

[W,V] = kap([z beta L]);
%vkap = kap(space2,[z beta L]);
%wstarq = Nconv_lovett(vkap,q);
%if we assume to be at a solution then we can compute this as follows:
wstarq = -log(exp(beta*V).*q./(z*(L*beta/2 - q)));
wstarrho = 2*wstarq/beta/L;

Quadratic = rho.*wstarrho/2;
intQuadratic = dx*sum(Weights.*Quadratic);

integral = dx*sum(Weights.*rho)*L/2;
adsorption = dx*norm(Weights.*(rho-integral/L),1)*(L/2)/L;

energy = (1/beta)*dx*sum(Weights.*(rho.*reallog(rho) + (1-rho).*reallog(1-rho)))*(L/2) + intQuadratic*(L/2)^2 - ...
    (L/2)*dx*sum(Weights.*rho.*(mu-V));

q = q/(dx*sum(Weights.*q));entropy = -dx*sum(Weights.*(q.*reallog(q)));

end