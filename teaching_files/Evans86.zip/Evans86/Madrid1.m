clc

[p,f] = ERun(-3);
[p,f] = ERun(p,f);
[p,f] = ERun(p,f);
bifdiag(p,f);
illustrate(p,[114 218],f);

