function F = fftsin(v)
    n = length(v);
    ft = -imag(fft([0 v],2*n+2));
    F = ft(2:n+1);
return