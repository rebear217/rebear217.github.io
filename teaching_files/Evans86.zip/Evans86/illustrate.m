function illustrate(path,posns,folds)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global dx space ContinuationParameter NPTS space2 space

[n,m]=size(path);

K = length(posns);

if nargin < 3
    folds = [];
end

figure(1);
subplot(1,K+1,1);
bifdiag2(path,folds);hold on;
title('Bifurcation diagram','Fontsize',12);

for j=1:K
    T = posns(j);
    
 	params = path(T,NPTS+1:end);

    mu = params(1);
    beta = params(2);
    L = params(3);
    z = exp(mu*beta);

    h = path(T,1:NPTS);
    [energy,adsorption,integral] = measures(h,params);
    subplot(1,K+1,1);hold on;
    plot(params(ContinuationParameter),energy,'.k','Markersize',18);

    subplot(1,K+1,j+1);hold off;

    h = 2*h/L/beta;

    a=plot((L/2)*space,h,'-k');
    axis([-L/2 L/2 0 1]);
    b=xlabel([' L = ',num2str(L)]);
    d=ylabel(' \rho(x)');

    if j < 3
        c=title(['(\mu,\beta,L) = (',num2str(mu),',',num2str(beta),',',num2str(L),')' ]);
        set(c,'FontSize',12,'FontName','Times');
    end

    
    set(gca,'LineWidth',1,'FontSize',12,'FontName','Times','FontWeight','bold');
    set(a,'LineWidth',2);
    set(b,'FontSize',14,'FontName','Times');
    set(d,'FontSize',14,'FontName','Times');

end
