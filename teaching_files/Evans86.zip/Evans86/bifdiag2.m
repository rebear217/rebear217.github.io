function bifdiag2(path,folds)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global dx space2 NPTS ContinuationParameter ContinuationParameters

if nargin == 1
    folds = [];
end

nParams = length(ContinuationParameters);

[n,m]=size(path);
params = zeros(n,1);
adsorption = zeros(n,1);Norm2=zeros(n,1);energy = zeros(n,1);
N = zeros(n,1);

disp('please wait');

Ls = path(:,end);
betas = path(:,end-1);
mus = path(:,end-2);
zs = exp(mus.*betas);

for i=1:n,
    params(i) = path(i,NPTS + ContinuationParameter);
	q=path(i,1:NPTS);
    [energy(i),adsorption(i)] = measures(q,[mus(i) betas(i) Ls(i)]);
    rho = 2*q/Ls(i)/betas(i);
    Norm2(i) = norm(rho,inf);
end

%figure(1);
%plot(params,adsorption,'-r','Linewidth',1);
%ylabel('adsorption (\int_{-1}^1 |\rho(x)-\rho_m| dx/2)');
plot(params,energy,'-b','Linewidth',1);
ylabel('Grand potential  \Omega(\rho)','FontSize',12,'FontName','Aerial');

a=xlabel(ContinuationParameters(ContinuationParameter));
if (ContinuationParameter==2)
    c=title(['Bifurcation diagram with \mu = ',num2str(mus(1)),', L = ',num2str(Ls(1))],'FontSize',12,'FontName','Aerial');
elseif (ContinuationParameter==3)
    c=title(['Bifurcation diagram with \mu = ',num2str(mus(1)),', \beta = ',num2str(betas(1))],'FontSize',12,'FontName','Aerial');
else
    c=title(['Bifurcation diagram with L = ',num2str(Ls(1)),', \beta = ',num2str(betas(1))],'FontSize',12,'FontName','Aerial');
end
xlabel(ContinuationParameters(ContinuationParameter),'FontSize',14,'FontName','Times');

set(a,'FontSize',12,'FontName','Times','FontWeight','bold');
set(c,'FontSize',12,'FontName','Aerial');

[N,M] = size(folds);

if not(isempty(folds))
  for i = 1:N
    param = folds(i,2*NPTS + ContinuationParameter);

	q=folds(i,1:NPTS);
%    k=folds(i,NPTS+1:2*NPTS);
 	mu=folds(i,end-2);
 	beta=folds(i,end-1);
 	L=folds(i,end);
    
    [qenergy,qadsorption,qintegral] = measures(q,[mu beta L]);
    figure(1);hold on;
%    plot(param,qadsorption,'.b','Markersize',18);
    plot(param,qenergy,'.r','Markersize',18);
  end
else
  hold on;plot(params,energy,'-b','Linewidth',1);
end