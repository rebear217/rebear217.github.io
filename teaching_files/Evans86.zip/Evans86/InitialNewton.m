function [Guess,Converged] = InitialNewton(p,ip,start)

global space NPTS restart gmsteps gmtol dx space2

Maxits = 11;
errorTol = 1e-8;

if nargin < 3
    Guess = 0.4*ones(1,NPTS);
%    Guess = 0.2 + 0.05*cos(space*3);
else
    Guess = start;
end

i = 1;
error = 1;

while (error > errorTol) && (i < Maxits)
    rhs = f(Guess,p);
    [step,gmresI] = cgs(@dfT,rhs',gmtol,gmsteps,[],[],[],Guess,p);
    if (gmresI > 0)
        [step,gmresI] = gmres(@dfT,rhs',restart,gmtol,gmsteps,[],[],[],Guess,p);
        disp('Used GMRES');
    end
    NewGuess = Guess - step';
    error = norm(step,inf)/norm(NewGuess,inf);
    Guess = NewGuess;
    i = i + 1;
    plot(space,Guess);drawnow;
end
%pause;
Converged = 1;
if ((i >= Maxits) || (error > errorTol) || not(isempty(find(isnan(Guess)))))
    disp('** Initial Newton iteration has not converged **');
%    Guess = NaN;
    Converged = 0;
else
    disp(['* Found initial point on curve at parameter value * : ',num2str(p(ip))]);
end

return