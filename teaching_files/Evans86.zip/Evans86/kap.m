function [ww,vv] = kap(p)

global NPTS space space2 dx Weights

L = p(3);

r = space2;

rpos = L*r(NPTS+1:end)/2;

%%%%%%%%%%%%%%%%%%%%%%%%%%
%LJ
%%%%%%%%%%%%%%%%%%%%%%%%%%
%p = 9;q = 3;
%uurpos = -1 + exp(-Beta*((1./rpos).^p-(1./rpos).^q));

alpha = 1;
lambda = 1;
epsilon = 2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%short range
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uurpos = -alpha*lambda^2*exp(-lambda*rpos);
ww = [fliplr(uurpos) -alpha*lambda^2 uurpos];
%with alpha = lambda = 1 -> mu_inf = -1, T_inf = 1/2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%long range
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%p = 9;uurpos = -alpha* ( (rpos < lambda) + (rpos >= lambda).*rpos.^(-p)) ;
%ww = [fliplr(uurpos) -alpha uurpos];
%with alpha = lambda = 1 -> mu_inf = -1.125, T_inf = 0.5625
%plot(rpos,uurpos);pause;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r = space;
vv = -epsilon*(exp(-lambda*L*abs(r-1)/2) + exp(-lambda*L*abs(r+1)/2));

return