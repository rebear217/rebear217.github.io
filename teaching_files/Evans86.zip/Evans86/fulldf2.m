function D = fulldf2(K,x,p,Dp,s0,sig0)

global NPTS

K = K';
D = [df(K(1:NPTS),x,p) + Dp*K(NPTS+1),dot(s0,K(1:NPTS)) + sig0*K(NPTS+1)];
D = D';
