function energy = functional(q,p,wstarq)

global dx Weights space

mu = p(1);
beta = p(2);
L = p(3);

z = exp(beta*mu);

rho = 2*q/L/beta;
%mu = log(z)/beta;

[W,V] = kap([z beta L]);
if nargin == 2
    wstarq = Nconv_lovett(vkap,q);
end

wstarrho = 2*wstarq/beta/L;
Quadratic = rho.*wstarrho/2;
intQuadratic = dx*sum(Weights.*Quadratic);

%energy = (1/beta)*dx*sum(Weights.*(rho.*reallog(rho) + (1-rho).*reallog(1-rho)))*(L/2) + ...
%    intQuadratic*(L/2)^2 - (L/2)*dx*sum(Weights.*rho.*(mu-V));

energy = (1/beta)*dx*sum(Weights.*(rho.*reallog(rho) + (1-rho).*reallog(1-rho))) + ...
    intQuadratic*(L/2) - dx*sum(Weights.*rho.*(mu-V));
