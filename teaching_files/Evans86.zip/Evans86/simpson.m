function w = simpson(n)

if( 2*fix(n/2) + 1 > n)
    error('vectors length must be an odd number')
end

mask = zeros(1,n);
mask(1) = 1; mask(n) = 1;
mask(2:2:n) = 4 * ones(1,(n-1)/2);
if (n>3)
	mask(3:2:n-2) = 2 * ones(1,(n-3)/2);
end

w = mask/3;

return