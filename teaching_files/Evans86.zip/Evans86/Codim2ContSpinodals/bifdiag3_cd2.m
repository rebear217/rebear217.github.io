function bifdiag3_cd2(folds)

global NPTS ContinuationParameter2 ContinuationParameters2

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
mus = folds(:,2*NPTS + 1);
betas = folds(:,2*NPTS + 2);
Ls = folds(:,2*NPTS + 3);

zs = exp(mus.*betas);

[n,m] = size(folds);

title(['Loci of spinodals'],'FontSize',12);
hold on;
plot3(1./betas,Ls,mus,'--b','Linewidth',2);
zlabel('chemical potential','FontSize',14,'FontName','Aerial');
ylabel('pore width','FontSize',14,'FontName','Aerial');
xlabel('T^*','FontSize',14);