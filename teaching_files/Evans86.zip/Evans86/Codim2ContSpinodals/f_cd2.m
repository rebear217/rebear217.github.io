function F=f_cd2(x,p)

global NPTS

q = x(1:NPTS);
k = x(NPTS+1:end-1);

mu = x(end);
beta = p(1);
L = p(2);

z = exp(beta*mu);

[W,V] = kap([z beta L]);

wstarq = Nconv_lovett(W,q);

A = -q + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq));
B = -k - (z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* Nconv_lovett(W,k) ./ ((z + exp(beta*V) .* exp(wstarq)).^2);
C = norm(k)^2 - 1;

F = [A B C];
return