function D=df_cd2_analytic(K,x,p)

global NPTS space2 Beta

%n=2*NPTS+1;

q = x(1:NPTS);
k = x(NPTS+1:end-1);
mu = x(end);
beta = p(1);
L = p(2);

z = exp(mu*beta);

qD = K(1:NPTS);
KD = K(NPTS+1:end-1);
muD = K(end);

zD = beta*z*muD;

[W,V] = kap([z beta L]);

wstarq = Nconv_lovett(W,q);
wstarqD = Nconv_lovett(W,qD);
wstark = Nconv_lovett(W,k);
wstarKD = Nconv_lovett(W,KD);

D1 = -qD - exp(beta*V) .* exp(wstarq) .* wstarqD .* (z*L*beta/2)./ ((z + exp(beta*V) .* exp(wstarq)).^2) + ...
    (zD*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq)) + ...
    - zD*(z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq)).^2;

%B = -k - (z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* Nconv_lovett(W,k) ./ ((z + exp(beta*V) .* exp(wstarq)).^2);

D2 = -KD - (z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* wstarKD ./ ((z + exp(beta*V) .* exp(wstarq)).^2) + ...
    - (zD*L*beta/2) * exp(beta*V) .* exp(wstarq) .* wstark ./ ((z + exp(beta*V) .* exp(wstarq)).^2) + ...
    + 2*zD*(z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* wstark ./ ((z + exp(beta*V) .* exp(wstarq)).^3) + ...
    - (z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* wstarqD .* wstark ./ ((z + exp(beta*V) .* exp(wstarq)).^2) + ...
    + 2*(z*L*beta/2) * exp(beta*V).^2 .* exp(wstarq).^2 .* wstarqD .* wstark ./ ((z + exp(beta*V) .* exp(wstarq)).^3);

D3 = 2*sum(k.*KD);

D = [D1 D2 D3];

return