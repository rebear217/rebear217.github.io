function solplot_cd2(folds)

global Beta NPTS ContinuationParameter2 ContinuationParameters2 space

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
mus = folds(:,2*NPTS + 1);
betas = folds(:,2*NPTS + 2);
Ls = folds(:,2*NPTS + 3);

zs = exp(betas.*mus);

[n,m] = size(folds);

figure(15);
ylabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14);

for i = 1:n
    L = Ls(i);
    [energy,adsorption,integral,entropy] = measures(xs(i,:),[mus(i) betas(i) Ls(i)]);
    mu = mus(i);

%    params = ps(:,ContinuationParameter2);

subplot(2,1,1);
plot((L/2)*space,2*xs(i,:)/Ls(i)/betas(i),'-b','Linewidth',2);
title(['Solution at L = ',num2str(L),', \beta = ',num2str(betas(i)),', \mu = ',num2str(mus(i))],'FontSize',12);
ylabel('Density','FontSize',12);
axis([-L/2 L/2 0 1]);

subplot(2,1,2);
plot((L/2)*space,ks(i,:),'-r','Linewidth',2);
title('Unit 2-norm Nullspace','FontSize',12);
xlabel('Space [-L/2,L/2]','FontSize',12);
axis tight;
drawnow;

end