function bifdiag2_cd2(folds)

global NPTS ContinuationParameter2 ContinuationParameters2

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
mus = folds(:,2*NPTS + 1);
betas = folds(:,2*NPTS + 2);
Ls = folds(:,2*NPTS + 3);

zs = exp(mus.*betas);

[n,m] = size(folds);

energy = zeros(n,1);
integral = zeros(n,1);
for i = 1:n
    [energy(i),adsorption,integral(i),entropy] = measures(xs(i,:),[mus(i) betas(i) Ls(i)]);
end

figure(10);
hold on;
%subplot(2,1,1);hold on;
%plot(zs,integral./Ls,'-b','Linewidth',2);
%set(gca,'YDir','reverse');
%xlabel(ContinuationParameters2(1),'FontSize',14,'FontName','Times','FontWeight','bold');
%ylabel('mean density','FontSize',14);
title(['Loci of Spinodals at beta = ',num2str(betas(1))],'FontSize',12);

%subplot(2,1,2);

ylabel('reciprocal length (1/L)','FontSize',14,'FontName','Aerial');
xlabel('mean density','FontSize',14);

plot(integral./Ls,mus,'--b','Linewidth',2);
