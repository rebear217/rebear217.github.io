function bifdiag_cd2(folds)

global NPTS ContinuationParameter2 ContinuationParameters2

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
mus = folds(:,2*NPTS + 1);
betas = folds(:,2*NPTS + 2);
Ls = folds(:,2*NPTS + 3);

zs = exp(mus.*betas);

hold on;
plot(1./betas,mus,'--b','Linewidth',2);

xlabel('T^*','FontSize',14,'FontName','Times','FontWeight','bold');
ylabel('\mu','FontSize',14);
%title(['Loci of Spinodals at beta = ',num2str(betas(1))],'FontSize',12);
