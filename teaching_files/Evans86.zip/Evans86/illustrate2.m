function illustrate2(path,posns,folds)

global dx space ContinuationParameter NPTS space2 space

[n,m]=size(path);

K = length(posns);

if nargin < 3
    folds = [];
end

figure(1);
if K <= 2
    subplot(2,2,[ 1 3 ]);
elseif K >=3
    subplot(3,2,[ 1 3 5 ]);
else
    return
end

bifdiag2(path,folds);hold on;
title('Bifurcation diagram','Fontsize',12);

for j=1:K
    L = posns(j);
    
 	params = path(L,NPTS+1:end);

    mu = params(1);
    beta = params(2);
    R = params(3);
    z = exp(mu*beta);

    h = path(L,1:NPTS);
    [energy,adsorption,integral] = measures(h,params);
    h = 2*h/R/beta;
    
if K <= 2
    subplot(2,2,[ 1 3 ]);hold on;
else
    subplot(3,2,[1 3 5]);hold on;
end
plot(params(ContinuationParameter),energy,'.k','Markersize',18);

if K <= 2
    subplot(2,2,2*j);hold off;
else
    subplot(3,2,2*j);hold off;
end
    
    a=plot((R/2)*space,h,'-k');axis tight;
    %b=xlabel(['L = ',num2str(R)]);
    d=ylabel(' \rho(x)');
    axis([-R/2 R/2 0 1]);

    set(gca,'LineWidth',2,'FontSize',12,'FontName','Times','FontWeight','bold');
    set(a,'LineWidth',2);
%    set(b,'FontSize',12,'FontName','Times','FontWeight','bold');
    set(d,'FontSize',14,'FontName','Times');

    if j == 1
        c=title(['(\mu,\beta,L) = (',num2str(mu),',',num2str(beta),',',num2str(R),')' ]);
        set(c,'FontSize',12,'FontName','Times');
    end
end
