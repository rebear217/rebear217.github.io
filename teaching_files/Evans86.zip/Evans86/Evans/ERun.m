function [pth,FindFold]=ERun(P,FindFold,pastFold)

%Set physical variables to global before loading in data.

%if FindFold == 1 then computation only continues until the first fold point
%is found, although if FindFold \neq 1 then computation continues beyond this
%point. In either case, the all computed solutions values at the last fold
%point found, namely [gamma,k,beta,rho] is stored in FindFold. Here k is
%an approximate null-space vector with unit sum.

global dx mask restart gmsteps gmtol NPTS ...
    StepsAroundCurve MaxNewtonIts tol dt dtMax ...
    dtMin space space2 ContinuationParameter ContinuationParameters Weights

[LastStepsAroundCurve,m]= size(P);
q = 5;
NPTS = (5*3*3^q + 1)/2;

%%default starting point data

mu = -2; L = 6; beta = 1/0.25;
%mu = -2; L = 11; beta = 1/0.25;
z = exp(beta*mu);

setData(NPTS);

pth = [];

v = version;
if v(1) == 7
    fftw('planner','exhaustive');
elseif v(1) == 6
    fftw('wisdom','exhaustive');
end

%cd ..
%directoryString = cd;
%zPath = [directoryString,'/Evans'];
%path(path,directoryString);
%path(path,zPath);
%cd(zPath);

if (nargin == 1)
    FindFold = [];
end

if (m==1)
    if ContinuationParameter==1
        mu = P;
    elseif ContinuationParameter==3
        L = P;
    else
        beta = P;
    end
    
    disp('===============================================================');
    disp(['Mesh size is ',num2str(NPTS),', getting initial point on curve']);
    disp('===============================================================');
    disp('Beware - if z is not small enough, it may well not converge');
    disp(['Starting with (mu,beta,L) = (',num2str(mu),',',num2str(beta),',',num2str(L),')']);
    disp('-----------------------------------');
  
    [x0,foundstart] = InitialNewton([mu,beta,L],ContinuationParameter);
    if foundstart
        P = [x0 mu beta L];
        disp('Beginning continuation phase');    
    close all;drawnow;
        [C,FindFold] = cont(x0,[mu,beta,L],ContinuationParameter,FindFold);
        pth=[P ; C];
    else
        disp('Can''t find starting point at that parameter');
        if input('Try anyway? ')
            P = [x0 mu beta L];
            [C,FindFold] = cont(x0,[mu,beta,L],ContinuationParameter,FindFold);
            pth=[P ; C];
        end
    end
else
    disp('----------------------------');
    disp(['Solution dimension is ',num2str(m-3)]);
    NPTS = m-3;
    setData(NPTS);
    start = P(LastStepsAroundCurve,1:end-length(ContinuationParameters));
    Params = P(LastStepsAroundCurve,(end-length(ContinuationParameters)+1):end);
    if (LastStepsAroundCurve > 1)
        dt = abs(dt);
        LastParams = P(LastStepsAroundCurve-1,(end-length(ContinuationParameters)+1):end);
        dt = dt*sign(Params(ContinuationParameter)-LastParams(ContinuationParameter));
    end

    if nargin == 3
%        start = Minimise([pastFold,BB,L],start);
        P = [];
        p = [mu,beta,L];
        p(ContinuationParameter) = pastFold;
        [start,foundstart] = InitialNewton(p,ContinuationParameter,start);
        Params = p;
    end
    
    disp('============================');
    disp('Beginning continuation phase');
    disp('============================');
    [C,FindFold] = cont(start,Params,ContinuationParameter,FindFold);
    pth=[P ; C];
end
disp('---------------------');
disp('Finished Computations');
