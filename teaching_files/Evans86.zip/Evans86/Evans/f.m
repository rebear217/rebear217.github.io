function F=f(q,p)

mu = p(1);
beta = p(2);
L = p(3);

z = exp(mu*beta);

[W,V] = kap(p);
wstarq = Nconv_lovett(W,q);
F = -q + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq));

return