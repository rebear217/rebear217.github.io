function D=df(k,q,p)

mu = p(1);
beta = p(2);
L = p(3);
z = exp(mu*beta);

%exp_betaV = ones(size(q));

[W,V] = kap(p);
wstarq = Nconv_lovett(W,q);

D = -k - (z*L*beta/2) * exp(beta*V) .* exp(wstarq) .* Nconv_lovett(W,k) ./ ((z + exp(beta*V) .* exp(wstarq)).^2);

%del = 1e-4;
%D1=(f(q+del*k,p) - f(q-del*k,p))/2/del;
%norm(D1-D,inf)

return