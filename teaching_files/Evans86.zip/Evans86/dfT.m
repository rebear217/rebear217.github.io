function D=dfT(k,x,p)

k = k';
D = df(k,x,p)';

return