function solutionplot(path,f,step)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global Beta space NPTS ContinuationParameter ContinuationParameters

if nargin == 1
    f = [];
end

if nargin < 3
    step = 1;
end

[n,m]=size(path);

Ls = path(:,end);
betas = path(:,end-1);
mus = path(:,end-2);

zs = exp(mus.*betas);

oldparams = [0 0 0];
oldoldparams = [0 0 0];

%figure(111);
subplot(1,2,1);
bifdiag2(path,f);
bifdiag2(path,f);

for i=1:step:n,
 	L = Ls(i);
 	beta = betas(i);
 	mu = mus(i);
    params = [mu beta L];
    mu = mus(i);
    
    Params = path(i,NPTS + ContinuationParameter);
    
    if (params(ContinuationParameter)-oldparams(ContinuationParameter))*(oldparams(ContinuationParameter)-oldoldparams(ContinuationParameter))<0
        str = 'Red';
        lw = 4;
    else
        str = 'Blue';
        lw = 2;
    end

    q=path(i,1:NPTS);
    rho = 2*q/L/beta;
    [energy,adsorption] = measures(q,[mu beta L]);

    Q = rho;

    subplot(1,2,1);
    unplot;
    plot(Params,energy,'.b','Markersize',16);
    
    subplot(1,2,2);
    a=plot(L*space/2,Q,'-k');
    b=xlabel([' x \in [-L/2,L/2], where L = ',num2str(L)]);
    c=title(['Density profile for \mu = ',num2str(mu),', \beta = ',num2str(beta)]);
    d=ylabel(' \rho(x)');
    axis([-L/2 L/2 0 1.01]);

    set(a,'LineWidth',lw,'Color',str);
    set(b,'FontSize',12,'FontName','Aerial');
    set(c,'FontSize',12,'FontName','Aerial');
    set(d,'FontSize',14,'FontName','Aerial');

    drawnow;
    oldoldparams = oldparams;
    oldparams = params;
end
