function setData(N)

global dx restart gmsteps gmtol NPTS ...
    StepsAroundCurve MaxNewtonIts tol dt dtMax ...
    dtMin space space2 ContinuationParameter ContinuationParameters Weights

if nargin == 1
    NPTS = N;
end

ContinuationParameters = {'\mu','\beta','L'};
ContinuationParameter = 1;

%Continuation data
restart = 20;%for GMRES(restart)
gmsteps = 100;%maximum number GMRES iterations
gmtol = 1e-3;%tolerance for linear solver

%How many arc-length steps to take
StepsAroundCurve = 80;

Weights = simpson(NPTS);%Weights = trapezium(NPTS);

tol = 1e-8;%error residual for Newton steps

MaxNewtonIts = 20;%Max number of Newton corrections to take
dt = 0.1;%arc-length of a single step
dtMin = 0.1;
dtMax = 5;

space = 2*(-(NPTS-1)/2:(NPTS-1)/2)/(NPTS-1);
dx = 2/(NPTS-1);
space2 = 2*(-(NPTS-1):(NPTS-1))/(NPTS-1);