function solplot_cd2bTLmu(bins)

global NPTS ContinuationParameter2 ContinuationParameters2 space

q1s = bins(:,1:NPTS);
q2s = bins(:,NPTS+1:2*NPTS);
betas = bins(:,2*NPTS + 1);
mus = bins(:,2*NPTS + 2);
Ls = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);

[n,m] = size(bins);

%figure(17);

%params = ps;

for i = 1:n
    [energy1,adsorption1,integral1,entropy1,mu1] = measures(q1s(i,:),[mus(i) betas(i) Ls(i)]);
    [energy2,adsorption2,integral2,entropy2,mu2] = measures(q2s(i,:),[mus(i) betas(i) Ls(i)]);
    
    rho1 = 2*q1s(i,:)/Ls(i)/betas(i);
    rho2 = 2*q2s(i,:)/Ls(i)/betas(i);
    plot((Ls(i)/2)*space,rho1,'-b','Linewidth',2);hold on;
    plot((Ls(i)/2)*space,rho2,'-r','Linewidth',2); hold off;

title(['Coexisting solutions at L = ',num2str(Ls(i)),', \beta = ',num2str(betas(i)),', mu = ',num2str(mus(i))],'FontSize',12);
ylabel('Density','FontSize',12);
xlabel('Space [-L/2,L/2]','FontSize',12);
axis([-Ls(i)/2 Ls(i)/2 0 1]);
drawnow;

end