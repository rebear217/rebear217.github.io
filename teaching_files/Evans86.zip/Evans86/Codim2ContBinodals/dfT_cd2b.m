function D=dfT_cd2b(k,x,p)

k = k';
D = df_cd2b(k,x,p)';

return