function bifdiag22_cd2b(bins,t)

global Beta NPTS ContinuationParameter2 ContinuationParameters2

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
mus = bins(:,2*NPTS + 2);
betas = bins(:,2*NPTS + 1);
Ls = bins(:,2*NPTS + 3);

zs = exp(mus.*betas);

[n,m] = size(bins);

energy1 = zeros(n,1);
integral1 = zeros(n,1);
energy2 = zeros(n,1);
integral2 = zeros(n,1);
for i = 1:n
    [energy1(i),adsorption,integral1(i),entropy] = measures(rho1s(i,:),[mus(i) betas(i) Ls(i)]);
    [energy2(i),adsorption,integral2(i),entropy] = measures(rho2s(i,:),[mus(i) betas(i) Ls(i)]);
end

%figure(24);
hold on;
%set(gca,'YDir','reverse');

xlabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times','FontWeight','bold');
ylabel('reciprocal length','FontSize',14,'FontName','Aerial');

if nargin == 2
    title(['Coexisting solutions at L = ',num2str(Ls(1))],'FontSize',12);
end

ylabel('\mu','FontSize',14,'FontName','Aerial');
xlabel('mean density','FontSize',14);

plot(mus,energy1,'-k','Linewidth',2);hold on;
