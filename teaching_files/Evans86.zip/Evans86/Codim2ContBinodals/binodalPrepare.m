function bin = binodalPrepare(p,j1,j2)

%makes a near-binodal from [p,f] = ERun(0.1), say, ready as a starting point for continuation using codim_twob.m
%note that ERun uses the parameter z which is converted here into mu and beta

global NPTS space2

x1 = p(j1,1:NPTS);
x2 = p(j2,1:NPTS);

mu1 = p(j1,NPTS + 1);
beta1 = p(j1,NPTS + 2);
L1 = p(j1,NPTS + 3);

mu2 = p(j2,NPTS + 1);
beta2 = p(j1,NPTS + 2);
L2 = p(j2,NPTS + 3);

%Z = (z1+z2)/2;
%mu = log(Z)/((beta1 + beta2)/2)

b = [x1 x2 (beta1 + beta2)/2];
P = [(mu1+mu2)/2 (L1+L2)/2];

disp('--------------------------------------');
disp(['Initial inf-norm residual is ',num2str(norm(f_cd2b(b,P),inf))]);
disp('--------------------------------------');
[Guess,Converged] = InitialNewton_cd2b(P,b);

bin = [Guess P];
solplot_cd2b(bin);
disp(['Final inf-norm residual is ',num2str(norm(f_cd2b(Guess,P),inf))]);
disp('--------------------------------------');
