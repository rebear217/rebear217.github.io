function bifdiag_cd2b(bins,titleYesNo)

global Beta NPTS ContinuationParameter2 ContinuationParameters2

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
mus = bins(:,2*NPTS + 2);
betas = bins(:,2*NPTS + 1);
Ls = bins(:,2*NPTS + 3);

zs = exp(mus.*betas);

%figure(23);
%hold on;
%plot(zs,params);
plot(1./betas,mus,'-k','Linewidth',2);hold on;
ylabel('\mu','FontSize',14);
xlabel('T^*','FontSize',14);

if nargin == 2
    title(['Coexisting solutions at \mu = ',num2str(mus(1))],'FontSize',12);
end