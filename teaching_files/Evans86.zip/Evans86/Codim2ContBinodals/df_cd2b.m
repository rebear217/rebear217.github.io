function Da = df_cd2b(k,x,p)

global NPTS

Da = df_cd2_analyticb(k,x,p);
return

eps = 1e-7;
n=2*NPTS+1;

if norm(k) == 0
    D=zeros(1,n);
    return
end
eps = eps/norm(k);
if norm(x) > 0
    eps=eps*norm(x);
end
D1 = f_cd2b(x+eps*k,p);D2 = f_cd2b(x-eps*k,p);
D = (D1-D2)/2/eps;

%norm(Da(1:NPTS)-D(1:NPTS),inf)
%norm(Da(NPTS+1:end-1)-D(NPTS+1:end-1),inf)
%Da(end)-D(end)

return