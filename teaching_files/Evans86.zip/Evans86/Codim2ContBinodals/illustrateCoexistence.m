function illustrateCoexistence(bins)

global NPTS

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
mus = bins(:,2*NPTS + 2);
betas = bins(:,2*NPTS + 1);
Ls = bins(:,2*NPTS + 3);
zs = exp(mus.*betas);

subplot(1,3,1);
bifdiag_cd2b(bins);
bifdiag_cd2b(bins);
bifdiag_cd2b(bins);

subplot(1,3,3);
bifdiag2_cd2b(bins);
bifdiag2_cd2b(bins);

[m,n] = size(bins);

for j = 1:m
    subplot(1,3,2);
    unplot;
    solplot_cd2b(bins(j,:));
    drawnow;
    
    subplot(1,3,1);
    unplot;
    unplot;
    plot(1/betas(j),mus(j),'.r','MarkerSize',14);
    plot(1/betas(j),mus(j),'ob','MarkerSize',6,'Linewidth',2);
    
    drawnow;

    subplot(1,3,3);
    [energy1,adsorption,integral1,entropy] = measures(rho1s(j,:),[mus(j) betas(j) Ls(j)]);
    [energy2,adsorption,integral2,entropy] = measures(rho2s(j,:),[mus(j) betas(j) Ls(j)]);

    unplot;
    unplot;
    plot(integral1./Ls(j),mus(j),'.b','MarkerSize',18);
    plot(integral2./Ls(j),mus(j),'.r','MarkerSize',18);
    drawnow;
end