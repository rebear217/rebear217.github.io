function F=f_cd2b(x,p)

global NPTS space2

q1 = x(1:NPTS);
q2 = x(NPTS+1:end-1);

beta = x(end);
mu = p(1);
L = p(2);

z = exp(mu*beta);

[W,V] = kap([z beta L]);
wstarq1 = Nconv_lovett(W,q1);
wstarq2 = Nconv_lovett(W,q2);

A = -q1 + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq1));
B = -q2 + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq2));
C = functional(q1,[mu,beta,L],wstarq1) - functional(q2,[mu,beta,L],wstarq2);

F = [A B C];
return