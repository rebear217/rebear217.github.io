function D=df_cd2_analyticb(K,x,p)

global NPTS space2

delta = 1e-6;
n=2*NPTS+1;

q1 = x(1:NPTS);
q2 = x(NPTS+1:end-1);
beta = x(end);

mu = p(1);
L = p(2);

z = exp(mu*beta);
dzdbeta = z*mu;

qD1 = K(1:NPTS);
qD2 = K(NPTS+1:end-1);
betaD = K(end);

if norm(K) == 0
    D=zeros(1,n);
    return
end
delta = delta/norm(K);
if norm(x) > 0
    delta=delta*norm(x);
end

[W,V] = kap([z beta L]);
wstarq1 = Nconv_lovett(W,q1);
wstarq2 = Nconv_lovett(W,q2);
wstarqD1 = Nconv_lovett(W,qD1);
wstarqD2 = Nconv_lovett(W,qD2);

%A = -q1 + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq1));

D1 = -qD1 - (z*L*beta/2) * exp(beta*V) .* exp(wstarq1) .* wstarqD1 ./ ((z + exp(beta*V) .* exp(wstarq1)).^2) + ...
    + (z*L*betaD/2) ./ (z + exp(beta*V) .* exp(wstarq1)) + ...
    - betaD*(z*L*beta/2) * exp(beta*V) .* exp(wstarq1) .* V ./ ((z + exp(beta*V) .* exp(wstarq1)).^2) + ...
    + dzdbeta*betaD*((L*beta/2)./ (z + exp(beta*V) .* exp(wstarq1)) - (z*L*beta/2)./ ((z + exp(beta*V) .* exp(wstarq1)).^2));

D2 = -qD2 - (z*L*beta/2) * exp(beta*V) .* exp(wstarq2) .* wstarqD2 ./ ((z + exp(beta*V) .* exp(wstarq2)).^2) + ...
    + (z*L*betaD/2) ./ (z + exp(beta*V) .* exp(wstarq2)) + ...
    - betaD*(z*L*beta/2) * exp(beta*V) .* exp(wstarq2) .* V./ ((z + exp(beta*V) .* exp(wstarq2)).^2) + ...
    + dzdbeta*betaD*((L*beta/2)./ (z + exp(beta*V) .* exp(wstarq2)) - (z*L*beta/2)./ ((z + exp(beta*V) .* exp(wstarq2)).^2));

d31 = (functional(q1 + delta*qD1,[mu,beta+delta*betaD,L],wstarq1 + delta*wstarqD1)-functional(q1 - delta*qD1,[mu,beta-delta*betaD,L],wstarq1 - delta*wstarqD1));
d32 = (functional(q2 + delta*qD2,[mu,beta+delta*betaD,L],wstarq2 + delta*wstarqD2)-functional(q2 - delta*qD2,[mu,beta-delta*betaD,L],wstarq2 - delta*wstarqD2));
D3 = (d31 - d32)/delta/2;

D = [D1 D2 D3];

return