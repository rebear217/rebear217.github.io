function bifdiag3_cd2b(bins)

global Beta NPTS ContinuationParameter2 ContinuationParameters2

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
mus = bins(:,2*NPTS + 2);
betas = bins(:,2*NPTS + 1);
Ls = bins(:,2*NPTS + 3);
zs = exp(betas.*mus);


[n,m] = size(bins);

energy = zeros(n,1);
integral = zeros(n,1);

%for i = 1:n
%    [energy(i),adsorption,integral(i),entropy] = measures(q1s(i,:),[zs(i) betas(i) Ls(i)]);
%end

%figure(24);
hold on;
%set(gca,'YDir','reverse');

plot3(1./betas,Ls,mus,'-k','Linewidth',2);hold on;

title(['Loci of critical points'],'FontSize',12);

zlabel('chemical potential','FontSize',14,'FontName','Aerial');
ylabel('pore width','FontSize',14,'FontName','Aerial');
xlabel('T^*','FontSize',14);

