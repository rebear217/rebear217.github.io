function w = trapezium(n)

w = ones(1,n);
w(1) = 1/2; w(n) = 1/2;

return