function BinsOut = codim_twoCrit(Bins)

%Start with a fold point with data contained in Bins and calculate a locus
%of critical points

global space StepsAroundCurve NPTS dt dtMax dtMin gmtol ContinuationParameter2 ContinuationParameters2 restart gmsteps

ContinuationParameter2 = 1;
ContinuationParameters2 = {'\mu'};

if nargin == 0
    disp('No fold data entered to begin');
    return
end

[LastStepsAroundCurve,m]= size(Bins);
Bin = Bins(end,:);

StepsAroundCurve = 40;
dt = 0.15;
dtMax = 5;
dtMin = 1;

tol = 1e-8;

gmtol = 1e-3;
restart = 20;
gmsteps = 200;

%cd ..
%directoryString = cd;
%zPath = [directoryString,'\Beta'];
%codim2path = [directoryString,'\Codim2Cont_Binodals'];
%rmpath(zPath)
%cd(codim2path);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    x = Bin(1:end-1);p = Bin(end);
    if (LastStepsAroundCurve > 1)
        dt = abs(dt);
        Lastp = Bins(LastStepsAroundCurve-1,end);
        dt = dt*sign(p(ContinuationParameter2)-Lastp(ContinuationParameter2));
    end
    
    if nargin == 2
        q = x(1:NPTS);
        l = x(NPTS+1:2*NPTS);
        L = x(end-1);
        beta = x(end);
        spaceOld = space;
        NPTS = 3*NPTS;
        setData(NPTS);
        qNew = interp1(spaceOld,q,space,'spline');
        lNew = interp1(spaceOld,l,space,'spline');
        x = [qNew lNew L beta];
        Bins = [];
        LastStepsAroundCurve = 0;
    end

    disp('===============================================================');
    disp(['Mesh size is ',num2str(NPTS),', Getting initial point on Codim2 curve']);
    disp(['Starting with (mu,beta,L) = (',num2str(p(1)),', ',num2str(x(end)),', ',num2str(x(end-1)),')']);
    disp(['Initial inf norm residual ',num2str(norm(f_crit(x,p),inf))]);
    disp('===============================================================');

[x,Converged] = InitialNewton_crit(p,x);

    disp(['New inf norm residual ',num2str(norm(f_crit(x,p),inf))]);
    disp('===============================================================');

    path_run = cont_crit(x,p,ContinuationParameter2);

if LastStepsAroundCurve > 1
    BinsOut = [Bins ; path_run];
else
    BinsOut = path_run;
end

Ls = BinsOut(:,end-2);
betas = BinsOut(:,end-1);
mus = BinsOut(:,end);

figure(112);
plot3(Ls,betas,mus);hold on;
plot3(Ls,betas,mus,'.r');
end

%ParameterList = [zs BBs Rs]

%LastSolution = Fold;

%fig = figure;
%plot(ParameterList(:,2),ParameterList(:,1),'ob');hold on;
%plot(ParameterList(:,2),ParameterList(:,1),'-k');hold off;
%title(' Phase-Diagram ');
%xlabel(' Z ');
%ylabel(' BB ');

%Solutions = [ Bins ; path_run];