function D=dfT_crit(k,x,p)

k = k';
D = df_crit(k,x,p)';

return