function bifdiag3_crit(bins)

global Beta NPTS ContinuationParameter2 ContinuationParameters2

qs = bins(:,1:NPTS);
ls = bins(:,NPTS+1:2*NPTS);
Ls = bins(:,2*NPTS + 1);
betas = bins(:,2*NPTS + 2);
mus = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);


[n,m] = size(bins);

energy = zeros(n,1);
integral = zeros(n,1);

for i = 1:n
    [energy(i),adsorption,integral(i),entropy] = measures(qs(i,:),[zs(i) betas(i) Ls(i)]);
end

%figure(24);
hold on;
%set(gca,'YDir','reverse');

title(['Loci of critical points'],'FontSize',12);

zlabel('chemical potential','FontSize',14,'FontName','Aerial');
ylabel('pore width','FontSize',14,'FontName','Aerial');
xlabel('T^*','FontSize',14);

plot3(1./betas,Ls,mus,'-r','Linewidth',3);hold on;
