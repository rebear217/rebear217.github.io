function bifdiag_crit(bins)

global NPTS ContinuationParameter2 ContinuationParameters2

qs = bins(:,1:NPTS);
ls = bins(:,NPTS+1:2*NPTS);
Ls = bins(:,2*NPTS + 1);
betas = bins(:,2*NPTS + 2);
mus = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);


[n,m] = size(bins);

%figure(23);
%hold on;
%plot(zs,params);

plot(1./betas,mus,'-r','Linewidth',3);hold on;
ylabel('\mu','FontSize',14);
xlabel('T^*','FontSize',14);
