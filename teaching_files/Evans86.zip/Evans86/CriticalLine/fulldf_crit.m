function D = fulldf_crit(K,x,p,Dp,s0,sig0)

global NPTS

K = K';
D = [df_crit(K(1:2*NPTS+2),x,p) + Dp*K(2*NPTS+3),dot(s0,K(1:2*NPTS+2)) + sig0*K(2*NPTS+3)];
D = D';
