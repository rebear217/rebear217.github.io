function bifdiag2_crit(bins)

global Beta NPTS ContinuationParameter2 ContinuationParameters2

qs = bins(:,1:NPTS);
ls = bins(:,NPTS+1:2*NPTS);
Ls = bins(:,2*NPTS + 1);
betas = bins(:,2*NPTS + 2);
mus = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);


[n,m] = size(bins);

energy = zeros(n,1);
integral = zeros(n,1);

for i = 1:n
    [energy(i),adsorption,integral(i),entropy] = measures(qs(i,:),[zs(i) betas(i) Ls(i)]);
end

%figure(24);
hold on;
%set(gca,'YDir','reverse');

xlabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times','FontWeight','bold');
ylabel('reciprocal length','FontSize',14,'FontName','Aerial');

title(['Loci of critical points'],'FontSize',12);

ylabel('reciprocal length (1/L)','FontSize',14,'FontName','Aerial');
xlabel('mean density','FontSize',14);

plot(integral./Ls,1./Ls,'-r','Linewidth',2);hold on;
