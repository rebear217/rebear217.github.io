function solplot_crit(bins)

global NPTS ContinuationParameter2 ContinuationParameters2 space

qs = bins(:,1:NPTS);
ls = bins(:,NPTS+1:2*NPTS);
Ls = bins(:,2*NPTS + 1);
betas = bins(:,2*NPTS + 2);
mus = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);


[n,m] = size(bins);

figure(15);

%params = ps;

for i = 1:n
    [energy,adsorption,integral,entropy] = measures(qs(i,:),[zs(i) betas(i) Ls(i)]);
    
    rho = 2*qs(i,:)/Ls(i)/betas(i);

    subplot(1,2,1);
    plot((Ls(i)/2)*space,rho,'-b','Linewidth',2);
    axis([-Ls(i)/2 Ls(i)/2 0 1]);
    title(['Critical solution at L = ',num2str(Ls(i)),', \beta = ',num2str(betas(i)),', \mu = ',num2str(mus(i))],'FontSize',12);
    ylabel('Density','FontSize',12);
    xlabel('Space [-L/2,L/2]','FontSize',12);

    subplot(1,2,2);
    plot((Ls(i)/2)*space,ls(i,:),'-r','Linewidth',2);
    axis([-Ls(i)/2 Ls(i)/2 min(ls(i,:)) max(ls(i,:))]);
%    ylabel('Density','FontSize',12);
    xlabel('Space [-L/2,L/2]','FontSize',12);
    drawnow;

end