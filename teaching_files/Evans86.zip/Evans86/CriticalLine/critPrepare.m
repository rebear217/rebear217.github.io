function critOut = critPrepare(crit)

%given output from codim_twob in crit, find a line of critical points
%as a function of mu starting from crit(end,:) as the critical point guess

global NPTS space2 dx Weights

crit = crit(end,:);

rho1 = crit(1:NPTS);
rho2 = crit(NPTS+1:2*NPTS);
beta = crit(2*NPTS+1);
mu = crit(:,2*NPTS + 2);
L = crit(:,2*NPTS + 3);

l = rho2 - rho1;
%l = l/norm(l);
l = l/sqrt(dx*sum(Weights.*l.^2));
l = l*sign(l(1));

%z = exp(beta*mu);

critPoint = [(rho1+rho2)/2 l L beta];

disp('--------------------------------------');
disp(['Initial inf-norm residual is ',num2str(norm(f_crit(critPoint,mu),inf))]);
disp('--------------------------------------');

[critPoint,Converged] = InitialNewton_crit(mu,critPoint);

critOut = [critPoint mu];
solplot_crit(critOut);

disp(['Final inf-norm residual is ',num2str(norm(f_crit(critPoint,mu),inf))]);
disp('--------------------------------------');
