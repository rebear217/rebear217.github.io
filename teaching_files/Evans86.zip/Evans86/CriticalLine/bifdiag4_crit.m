function bifdiag4_crit(bins)

global Beta NPTS ContinuationParameter2 ContinuationParameters2
qs = bins(:,1:NPTS);
ls = bins(:,NPTS+1:2*NPTS);
Ls = bins(:,2*NPTS + 1);
betas = bins(:,2*NPTS + 2);
mus = bins(:,2*NPTS + 3);

zs = exp(betas.*mus);


[n,m] = size(bins);

figure(23);
%hold on;
%plot(zs,params);

subplot(1,3,3);
plot(1./betas,1./Ls,'-r','Linewidth',2);hold on;
ylabel('1/L','FontSize',14);
xlabel('T^*','FontSize',14);

subplot(1,3,2);
plot(1./betas,mus,'-r','Linewidth',2);hold on;
ylabel('\mu','FontSize',14);
xlabel('T^*','FontSize',14);
title(['Loci of critical points'],'FontSize',12);

subplot(1,3,1);
plot(Ls,mus,'-r','Linewidth',2);hold on;
xlabel('L','FontSize',14);
ylabel('\mu','FontSize',14);
