function F=f_crit(x,p)

global NPTS space2 dx Weights

q = x(1:NPTS);
l = x(NPTS+1:2*NPTS);
L = x(end-1);
beta = x(end);

mu = p(1);

rho = 2*q/L/beta;

z = exp(beta*mu);

[W,V] = kap([z beta L]);
%WW = space2.*W/2;

wstarq = Nconv_lovett(W,q);
wstarl = Nconv_lovett(W,l);
%Wstarrho = Nconv_lovett(WW,rho);
wstarrho = 2*wstarq/beta/L;

A = -q + (z*L*beta/2)./ (z + exp(beta*V) .* exp(wstarq));
B = l + beta*L*rho.*(1-rho).*wstarl/2;
C = dx*sum(Weights.*l.^2) - 1;

%D = 2*dx*sum(Weights.*l.*(reallog(rho) - reallog(1-rho)))/L;

%E = dx*sum(Weights.*l.*(reallog(rho./(1-rho))))/beta + (L/2)*dx*sum(Weights.*l.*wstarrho) + dx*sum(Weights.*(V-mu).*l) + ...
%    + (L/2)^2*dx*sum(Weights.*l.*Wstarrho);
D = dx*sum(Weights.*l.^2.*(2*rho - 1)./(rho.^2.*(1-rho).^2));

F = [A B C D];

return
