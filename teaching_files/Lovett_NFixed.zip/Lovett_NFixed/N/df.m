function D=df(k,x,p)

global space2 Nparticles dx Weights NPTS

%eps = 1e-6;
%n=NPTS+1;
%if norm(k) == 0
%    D=zeros(1,NPTS);
%    return
%end
%eps = eps/norm(k);
%if norm(x) > 0
%    eps=eps*norm(x);
%end
%D1 = f(x+eps*k,p);D2 = f(x-eps*k,p);
%D = (D1-D2)/2/eps;

%return


Beta = p(1);
R = p(2);

vkap = kap(space2,p);

cstarx = Nconv_lovett(vkap,x);
cstark = Nconv_lovett(vkap,k);

int_expCSX = dx*sum(Weights.*exp(cstarx));
D = Nparticles*Beta*exp(cstarx).*((cstark*int_expCSX - dx*sum(Weights.*exp(cstarx).*cstark))/((int_expCSX)^2)) - k;

%norm(Da - D,inf)

return