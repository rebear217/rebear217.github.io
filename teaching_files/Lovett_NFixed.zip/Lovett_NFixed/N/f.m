function F=f(x,p)

global space2 Nparticles Weights dx

%Direct correlation functions

Beta = p(1);
R = p(2);

vkap = kap(space2,p);
V = exp(Nconv_lovett(vkap,x));

F = Beta*Nparticles*V/(dx*sum(Weights.*V))-x;

return