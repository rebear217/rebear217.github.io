function solplot_cd2(folds)

global Beta NPTS ContinuationParameter2 ContinuationParameters2 space

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
zs = folds(:,2*NPTS + 1);
ps = folds(:,end);

[n,m] = size(folds);

figure(15);
ylabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14);

for i = 1:n
    R = ps(i);
    Beta = zs(i);
    [energy,adsorption,entropy,mu] = measures(xs(i,:),[Beta R]);

    params = ps(:,ContinuationParameter2);

subplot(2,1,1);

plot((R/2)*space,xs(i,:),'-b','Linewidth',2);
%having computed Q, we should plot q = L*rho/2 = Q/beta = xs(i,:)/beta;

title(['Solution at L = ',num2str(R),', \beta = ',num2str(Beta)],'FontSize',12);
ylabel('Density','FontSize',12);
axis tight;

subplot(2,1,2);
plot((R/2)*space,ks(i,:),'-r','Linewidth',2);
title('Unit 2-norm Nullspace','FontSize',12);
xlabel('Space [-L/2,L/2]','FontSize',12);
axis tight;
drawnow;

end

