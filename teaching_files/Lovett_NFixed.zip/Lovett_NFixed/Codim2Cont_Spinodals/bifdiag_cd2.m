function bifdiag_cd2(folds)

global Nparticles NPTS ContinuationParameter2 ContinuationParameters2

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
Betas = folds(:,2*NPTS + 1);
ps = folds(:,end);

params = ps;
hold on;
%plot(zs,params);hold on;
plot(Betas,params,'-b','Linewidth',1);
ylabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times');
xlabel('\beta','FontSize',14);
title(['Loci of Spinodals at N = ',num2str(Nparticles)],'FontSize',12);
