function pd=pderiv_cd2(x,p,i)

% Calculates the partial derivative of Fun(x,p) wrt the i-th entry in p

    h=1e-6;
    ei=zeros(size(p));
    ei(i)=h;
    pd1=f_cd2(x,p+ei);
    pd2=f_cd2(x,p-ei);
    pd=(pd1-pd2)/2/h;

return
