function bifdiag2_cd2(folds)

global Nparticles NPTS ContinuationParameter2 ContinuationParameters2

xs = folds(:,1:NPTS);
ks = folds(:,NPTS+1:2*NPTS);
zs = folds(:,2*NPTS + 1);
ps = folds(:,end);

[n,m] = size(folds);

energy = zeros(1,n);
mu = zeros(1,n);
for i = 1:n
    [energy(i),adsorption,entropy,mu(i)] = measures(xs(i,:),[zs(i) ps(i)]);
end

params = ps(:,ContinuationParameter2);
figure(10);
hold on;
plot(params,mu,'-b','Linewidth',1);
%set(gca,'YDir','reverse');

xlabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times');
ylabel('chemical potential','FontSize',14);
title(['Loci of Spinodals at N = ',num2str(Nparticles)],'FontSize',12);
