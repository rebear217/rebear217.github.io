function F=f_cd2(x,p)

global NPTS space2 Nparticles Weights dx

rho = x(1:NPTS);
k = x(NPTS+1:end-1);

Beta = x(end);
R = p(1);%R = p; in fact

vkap = kap(space2,[Beta R]);
cstarRHO = Nconv_lovett(vkap,rho);
cstark = Nconv_lovett(vkap,k);
int_expCSRHO = dx*sum(Weights.*exp(cstarRHO));

A = Beta*Nparticles*exp(cstarRHO)/int_expCSRHO - rho;
B = Nparticles*Beta*exp(cstarRHO).*((cstark*int_expCSRHO - dx*sum(Weights.*exp(cstarRHO).*cstark))/((int_expCSRHO)^2)) - k;
C = norm(k)^2 - 1;
F = [A B C];
return

