function D=dfT_cd2(k,x,p)

k = k';
D = df_cd2(k,x,p)';

return