function D = fulldf_cd2(K,x,p,Dp,s0,sig0)

global NPTS

K = K';
D = [df_cd2(K(1:2*NPTS+1),x,p) + Dp*K(2*NPTS+2),dot(s0,K(1:2*NPTS+1)) + sig0*K(2*NPTS+2)];
D = D';
