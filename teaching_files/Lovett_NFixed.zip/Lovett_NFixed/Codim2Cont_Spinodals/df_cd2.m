function D=df_cd2(k,x,p)

global NPTS

%Da = df_cd2_analytic(k,x,p);

%return

eps = 1e-6;
n=2*NPTS+1;

if norm(k) == 0
    D=zeros(1,n);
    return
end
eps = eps/norm(k);
if norm(x) > 0
    eps=eps*norm(x);
end
D1 = f_cd2(x+eps*k,p);D2 = f_cd2(x-eps*k,p);

D = (D1-D2)/2/eps;

%norm(Da-D,inf);


return
