function FoldsOut = codim_two(Folds)

%Start with a fold point with data contained in Fold and calculate a phase diagram

global Nparticles StepsAroundCurve NPTS dt dtMax dtMin gmtol ContinuationParameter2 ContinuationParameters2 restart gmsteps

ContinuationParameter2 = 1;
ContinuationParameters2 = {'L'};

if nargin == 0
    disp('No fold data entered to begin');
    return
end

[LastStepsAroundCurve,m]= size(Folds);
Fold = Folds(end,:);

StepsAroundCurve = 50;
dt = -1;
dtMax = 6;
dtMin = 0.5;

gmtol = 1e-3;
restart = 20;
gmsteps = 60;

%cd ..
%directoryString = cd;
%zPath = [directoryString,'\N'];
%codim2path = [directoryString,'\Codim2Cont_Spinodals'];

%rmpath(zPath)
%cd(codim2path);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = Fold(1:end-1);p = [Fold(end)];
    if (LastStepsAroundCurve > 1)
        dt = abs(dt);
        Lastp = Folds(LastStepsAroundCurve-1,end);
        dt = dt*sign(p(ContinuationParameter2)-Lastp(ContinuationParameter2));
    end

    disp('===============================================================');
    disp(['Mesh size is ',num2str(NPTS),', Getting initial point on Codim2 curve']);
    disp(['Starting with (Beta,L,N) = (',num2str(x(end)),', ',num2str(p(1)),', ',num2str(Nparticles),')']);
    disp(['Initial inf norm residual ',num2str(norm(f_cd2(x,p),inf))]);
    disp('===============================================================');

[x,Converged] = InitialNewton_cd2(p,x);

    disp(['New inf norm residual ',num2str(norm(f_cd2(x,p),inf))]);
    disp('===============================================================');

    path_run = cont_cd2(x,p,ContinuationParameter2);

if LastStepsAroundCurve > 1
    FoldsOut = [Folds ; path_run];
else
    FoldsOut = path_run;
end

zs = FoldsOut(:,end-1);
Rs = FoldsOut(:,end);

%figure(112);plot(zs,Rs);hold on;plot(zs,Rs,'.r');
end