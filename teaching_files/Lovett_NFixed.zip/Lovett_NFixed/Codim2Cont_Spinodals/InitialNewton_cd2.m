function [Guess,Converged] = InitialNewton_cd2(p,start)

global space NPTS restart gmsteps gmtol dx space2

Maxits = 120;
errorTol = 1e-7;
Guess = start;
i = 0;
error = 1;

while (error > errorTol) && (i < Maxits)
    rhs = f_cd2(Guess,p);
%    [step,gmresI] = gmres(@dfT_cd2,rhs',restart,gmtol,gmsteps,[],[],[],Guess,p);
    [step,gmresI] = cgs(@dfT_cd2,rhs',gmtol,gmsteps,[],[],[],Guess,p);
    NewGuess = Guess - step';
    error = norm(step,inf)/norm(NewGuess,inf);
    disp(num2str(error));
    Guess = NewGuess;
    i = i + 1;
end
Converged = 1;
if ((i >= Maxits) || (error > errorTol) || not(isempty(find(isnan(Guess)))))
    disp('** Initial Newton iteration has not converged **');
    Converged = 0;
else
    disp(['* Found initial point on curve at parameter values p = * : ',num2str(p)]);
end

return