function f = Fugacity(beta,m,z)
        f = beta*exp(beta*m)-z;
end