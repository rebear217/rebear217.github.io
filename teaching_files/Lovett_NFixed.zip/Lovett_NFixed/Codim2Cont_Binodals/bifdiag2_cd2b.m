function bifdiag2_cd2(bins)

global Nparticles NPTS ContinuationParameter2 ContinuationParameters2

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
zs = bins(:,2*NPTS + 1);
params = bins(:,end);

[n,m] = size(bins);

energy1 = zeros(1,n);
mu1 = zeros(1,n);
energy2 = zeros(1,n);
mu2 = zeros(1,n);
for i = 1:n
    [energy1(i),adsorption,entropy,mu1(i)] = measures(rho1s(i,:),[zs(i) params(i)]);
    [energy2(i),adsorption,entropy,mu2(i)] = measures(rho2s(i,:),[zs(i) params(i)]);
end

figure(10);hold on;
plot(params,mu1,'-k','Linewidth',1);hold on;
plot(params,mu2,'-k','Linewidth',1);
%set(gca,'YDir','reverse');

xlabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times','FontWeight','bold');
ylabel('chemical potential','FontSize',14);
title(['Loci of Spinodals at N = ',num2str(Nparticles)],'FontSize',12);
