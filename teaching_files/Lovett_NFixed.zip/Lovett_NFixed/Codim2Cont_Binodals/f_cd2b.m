function F=f_cd2b(x,p)

global NPTS space2 Nparticles Weights dx

rho1 = x(1:NPTS);
rho2 = x(NPTS+1:end-1);
Beta = x(end);

R = p(1);% R = p;

vkap = kap(space2,[Beta R]);
V1 = Nconv_lovett(vkap,rho1);
V2 = Nconv_lovett(vkap,rho2);

A = Beta*Nparticles*exp(V1)/(dx*sum(Weights.*exp(V1))) - rho1;
B = Beta*Nparticles*exp(V2)/(dx*sum(Weights.*exp(V2))) - rho2;
C = functional(rho1,[Beta,R],V1) - functional(rho2,[Beta,R],V2);
F = [A B C];
return

return