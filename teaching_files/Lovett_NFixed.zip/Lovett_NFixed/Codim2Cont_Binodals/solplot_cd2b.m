function solplot2_cd2(bins)

global Nparticles NPTS ContinuationParameter2 ContinuationParameters2 space

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
Betas = bins(:,2*NPTS + 1);
ps = bins(:,end);

[n,m] = size(bins);

figure(17);

%params = ps;

for i = 1:n
    R = ps(i);
    [energy1,adsorption1,entropy1,mu1] = measures(rho1s(i,:),[Betas(i) R]);
    [energy2,adsorption2,entropy2,mu2] = measures(rho2s(i,:),[Betas(i) R]);
  
plot((R/2)*space,rho1s(i,:),'-b','Linewidth',2);hold on;
plot((R/2)*space,rho2s(i,:),'-r','Linewidth',2); hold off;

title(['Coexisting solutions at L = ',num2str(R),', \beta = ',num2str(Betas(i))],'FontSize',12);
ylabel('Density','FontSize',12);
xlabel('Space [-L/2,L/2]','FontSize',12);
axis tight;
drawnow;

end