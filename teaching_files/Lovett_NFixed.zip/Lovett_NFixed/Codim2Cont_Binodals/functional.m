function [energy,beta] = functional(Q,p,V)

global dx space2 Weights space

Beta = p(1);
L = p(2);

q = Q/Beta;

if nargin == 2
    vkap = kap(space2,[Beta L]);
    V = Nconv_lovett(vkap,q);
end

Quadratic = 0.5*q.*V;
intQuadratic = dx*sum(Weights.*Quadratic);

%integral = dx*sum(Weights.*q);% = N, note
energy = (1/Beta)*dx*sum(Weights.*(q.*(reallog(2*q/L)-1))) - intQuadratic;
