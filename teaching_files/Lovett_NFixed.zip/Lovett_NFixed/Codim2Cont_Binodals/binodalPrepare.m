function bin = binodalPrepare(p,j1,j2)

%makes a near-solution ready as a starting point for continuation using codim_twob.m

global NPTS space2 Nparticles

x1 = p(j1,1:NPTS);
x2 = p(j2,1:NPTS);

Beta1 = p(j1,NPTS + 1);
R1 = p(j1,NPTS + 2);

Beta2 = p(j2,NPTS + 1);
R2 = p(j2,NPTS + 2);

b = [x1 x2 (Beta1+Beta2)/2];
P = [(R1+R2)/2];

disp('--------------------------------------');
disp(['Initial inf-norm residual is ',num2str(norm(f_cd2b(b,P),inf))]);
disp('--------------------------------------');
[Guess,Converged] = InitialNewton_cd2b(P,b);

bin = [Guess P];
solplot_cd2b(bin);
disp(['Final inf-norm residual is ',num2str(norm(f_cd2b(Guess,P),inf))]);
disp('--------------------------------------');
