function path = cont_cd2b(x,p,ip)

% Continue the solution of Fun(x,p)=0 in the ip-th parameter
% using x as the initial guess for a point on the curve.

global ContinuationParameters2 StepsAroundCurve MaxNewtonIts tol dt NPTS dtMax dtMin gmtol restart gmsteps

N = 2*NPTS + 1;

binPoint = 0;
path = [];

x0=x;
p0=p(ip);
disp(['* Starting continuation from input at parameter value * : ',num2str(p0)]);

Dp = pderiv_cd2b(x0,p,ip);
RHS = zeros(1,N+1);
RHS(N+1) = 1;
%matlab version 6
[z0,gmresI] = gmres(@dfT_cd2b,-Dp',restart,gmtol,gmsteps,[],[],[],x0,p);
if (gmresI > 0)
    [z0,gmresI] = cgs(@dfT_cd2b,-Dp',gmtol,gmsteps,[],[],[],x0,p);    
end

%matlab version 7[z0,gmresI] =gmres(@dfT,-Dp',[],gmtol,10,[],[],[],x0,p);
z0 = z0';
if not(gmresI==0)
    disp([' ** Can''t find predictor, stopping ** ']);
    return
end
disp(['Found initial predictor']);

frac=sqrt(dot(z0,z0)+1);
s0 = z0/frac;
sig0= 1/frac;
opts.disp = 0;

for its=1:StepsAroundCurve,

  p(ip)=p0;

  xg=x0+dt*s0;
  pg=p0+dt*sig0;

  step=zeros(1,N+1);
  w = zeros(1,N+1);
  NewtonIts = 0;

  Dp = pderiv_cd2b(xg,p,ip);
  error = 1;
  
  while (error > tol) && (NewtonIts<=MaxNewtonIts),

    p(ip)=pg;
    rhsx=-f_cd2b(xg,p);
    rhss=dt - s0*(xg-x0)' - sig0*(pg-p0);
    rhs=[rhsx,rhss];

    OldStep = step';
    [step,gmflag] = gmres(@fulldf_cd2b,rhs',restart,gmtol,gmsteps,[],[],OldStep,xg,p,Dp,s0,sig0);
    if (gmflag > 0)
        [step,gmflag] = cgs(@fulldf_cd2b,rhs',gmtol,gmsteps,[],[],[],xg,p,Dp,s0,sig0);
    end
    step = step';
    if (gmflag > 0)
       disp('GMRES and CGS not converging');
%       disp('eigenvalues of derivative near ...');
%       eigs(@fulldf,N+1,4,0,opts,xg,p,Dp,s0,sig0)
       return
    end

    next=[xg,pg]+step;
    error = norm(step,2)/norm(next,2);
    xg=next(1:N);
    pg=next(N+1);
    p(ip)=pg;
    Dp = pderiv_cd2b(xg,p,ip);

    NewtonIts = NewtonIts+1;
    
  end
  
  if (NewtonIts > MaxNewtonIts)
    disp('Newton method not converging');
    return
  end
  
  if (NewtonIts <= 3)
      dt = 1.75*dt;
      if (abs(dt) > dtMax)
          dt = sign(dt)*dtMax;
      end
  end

  if (NewtonIts >= 5)
      dt = 5*dt/11;
      if (abs(dt) < dtMin)
          dt = sign(dt)*dtMin;
      end
  end

%  path(its,1:N+1)=[xg(1:N) pg];
  p(ip) = pg;
  path(its,1:N+1)=[xg(1:N) p];

  OldW = w';
  [w,gmflagw] = gmres(@fulldf_cd2b,RHS',restart,gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  if (gmflag > 0)
      [w,gmflagw] = cgs(@fulldf_cd2b,RHS',gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  end

  w = w';
  if (gmflagw > 0)
     disp('GMRES and CGS not converging in predictor step');
%     disp('eigenvalues of derivative near ...');
%     eigs(@dfT,N,2,0,opts,xg,p)
     return
  end

  w=w./norm(w,2);
  s0=w(1:N);
  sig0=w(N+1);

  x0=xg;
  p0=pg;
  
  if (its > 2)
    bindetected = ((pg-path(its-1,N+1))*(path(its-1,N+1)-path(its-2,N+1)) < 0);
    if bindetected
        disp('----------------------');
        disp(['Found possible critical point near ',num2str(pg)]);
        disp('----------------------');
    end
  end

  
  if mod(its,1)==0,
      disp([num2str(floor(100*its/StepsAroundCurve)),' Percent complete']);
      str = ['Last parameter value equals ',num2str(pg)];
      disp(str);
      disp(['Last no of Newton iterations is ',num2str(NewtonIts),' and dt = ',num2str(dt)]);
  end
  
end

return