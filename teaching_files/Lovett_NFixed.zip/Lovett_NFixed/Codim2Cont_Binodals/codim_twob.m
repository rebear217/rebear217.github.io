function BinsOut = codim_twob(Bins)

%Start with a fold point with data contained in Fold and calculate a phase diagram

global Nparticles StepsAroundCurve NPTS dt dtMax dtMin gmtol ContinuationParameter2 ContinuationParameters2 restart gmsteps

ContinuationParameter2 = 1;
ContinuationParameters2 = {'L'};

if nargin == 0
    disp('No fold data entered to begin');
    return
end

[LastStepsAroundCurve,m]= size(Bins);
Bin = Bins(end,:);

StepsAroundCurve = 20;
dt = 0.5;
dtMax = 10;
dtMin = 0.1;

gmtol = 1e-3;
restart = 20;
gmsteps = 60;

%cd ..
%directoryString = cd;
%zPath = [directoryString,'\N'];
%codim2path = [directoryString,'\Codim2Cont_Binodals'];

%rmpath(zPath)
%cd(codim2path);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = Bin(1:end-1);p = [Bin(end)];
    if (LastStepsAroundCurve > 1)
        dt = abs(dt);
        Lastp = Bins(LastStepsAroundCurve-1,end);
        dt = dt*sign(p(ContinuationParameter2)-Lastp(ContinuationParameter2));
    end

    disp('===============================================================');
    disp(['Mesh size is ',num2str(NPTS),', Getting initial point on Codim2 curve']);
    disp(['Starting with (N,L,Beta) = (',num2str(Nparticles),', ',num2str(p(1)),', ',num2str(x(end)),')']);
    disp(['Initial inf norm residual ',num2str(norm(f_cd2b(x,p),inf))]);
    disp('===============================================================');

[x,Converged] = InitialNewton_cd2b(p,x);

    disp(['New inf norm residual ',num2str(norm(f_cd2b(x,p),inf))]);
    disp('===============================================================');

    path_run = cont_cd2b(x,p,ContinuationParameter2);

if LastStepsAroundCurve > 1
    BinsOut = [Bins ; path_run];
else
    BinsOut = path_run;
end

Betas = BinsOut(:,end-2);
Rs = BinsOut(:,end-1);

%figure(112);plot(Betas,Rs);hold on;plot(Betas,Rs,'.r');
end