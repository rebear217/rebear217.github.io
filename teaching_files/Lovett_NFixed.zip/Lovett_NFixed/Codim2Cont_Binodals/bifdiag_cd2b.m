function bifdiag_cd2b(bins)

global Nparticles NPTS ContinuationParameter2 ContinuationParameters2

rho1s = bins(:,1:NPTS);
rho2s = bins(:,NPTS+1:2*NPTS);
zs = bins(:,2*NPTS + 1);
ps = bins(:,end);

%figure(21);
hold on;
%plot(zs,params);
plot(zs,ps,'-k','Linewidth',1);hold on;
ylabel(ContinuationParameters2(ContinuationParameter2),'FontSize',14,'FontName','Times');
xlabel('\beta','FontSize',14);
title(['Loci of Binodals at N = ',num2str(Nparticles)],'FontSize',12);
