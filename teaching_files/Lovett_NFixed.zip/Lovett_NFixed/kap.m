function uu = kap(r,p)

global NPTS Nparticles

Beta = p(1);
L = p(2);
rpos = L*r(NPTS+1:end)/2;

%%%%%%%%%%%%%%%%%%%%%%%%%%
%LJ
%%%%%%%%%%%%%%%%%%%%%%%%%%
p = 9;q = 3;sigma = 1;
uurpos = -1 + exp(-Beta*((sigma./rpos).^p-(sigma./rpos).^q));
uu = [fliplr(uurpos) -1 uurpos];

%%%%%%%%%%%%%%%%%%%%%%%%%%
%Double Yukawa potential
%%%%%%%%%%%%%%%%%%%%%%%%%%
%sigma = 1/4; epsilon = 1;

%A = 2.02*sigma; a = 14.74/sigma; b = 2.68/sigma;
% uurpos = A*epsilon*(exp(-a*(rpos-sigma)) - exp(-b*(rpos-sigma)))./rpos;

%A1 = 1.6438;	Z1 = 14.7 ;	A2 = 2.03 ;	Z2 = 2.69 ;
%uurpos = (A1*epsilon*exp(-Z1*(rpos-sigma)) - A2*exp(-Z2*(rpos-sigma)))./rpos;

%uurpos = -1 + exp(-B*uurpos);
%uu = [fliplr(uurpos) -1 uurpos];


%%%%%%%%%%%%%%%%%%%%%%%%%%
%Potential from Lov+Still
%%%%%%%%%%%%%%%%%%%%%%%%%%
%uurpos = -(1+Beta*cos(rpos)).* (abs(rpos) < 1)/(2);
%uu = [fliplr(uurpos) -(1+Beta)/(2*pi) uurpos];

%plot(L*r,uu);
%pause

return;