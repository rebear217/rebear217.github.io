function bifdiag2(path,folds,ks)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global Nparticles dx space2 NPTS ContinuationParameter ContinuationParameters

if nargin == 1
    folds = [];
end

nParams = length(ContinuationParameters);

[n,m]=size(path);
params = zeros(n,1);
adsorption = zeros(n,1);Norm2=zeros(n,1);energy = zeros(n,1);
N = zeros(n,1);

disp('please wait');
for i=1:n,
    params(i) = path(i,NPTS + ContinuationParameter);
	q=path(i,1:NPTS);
 	R = path(i,end);
 	Beta = path(i,end-1);
    rho = R*q/2;
    [qenergy,qadsorption,qintegral] = measures(q,[Beta R]);
    energy(i)=qenergy;
    adsorption(i) = qadsorption;
end

figure(1);
%plot(params,adsorption,'-r','Linewidth',1);
%ylabel('adsorption (\int_{-1}^1 |\rho(x)-\rho_m| dx/2)');
plot(params,energy,'-b','Linewidth',1);
ylabel('energy','FontSize',12,'FontName','Aerial');

a=xlabel(ContinuationParameters(ContinuationParameter),'FontSize',14,'FontName','Aerial');
if (ContinuationParameter==1)
    title(['Bifurcation diagram with N = ',num2str(Nparticles),' where L = ',num2str(R)],'FontSize',12,'FontName','Aerial');
else
    title(['Bifurcation diagram with N = ',num2str(Nparticles),' where \beta = ',num2str(Beta)],'FontSize',12,'FontName','Aerial');
end

xlabel(ContinuationParameters(ContinuationParameter),'FontSize',14,'FontName','Aerial');

set(a,'FontSize',14,'FontName','Times');
%set(c,'FontSize',12,'FontName','Aerial');

[N,M] = size(folds);

if not(isempty(folds))
for i = 1:N
    param = folds(i,2*NPTS + ContinuationParameter);

	q=folds(i,1:NPTS);
%    k=folds(i,NPTS+1:2*NPTS);
 	Beta=folds(i,end-1);
 	R=folds(i,end);
    
    [qenergy,qadsorption,qintegral] = measures(q,[Beta R]);
    figure(1);hold on;
%    plot(param,qadsorption,'.b','Markersize',18);
    plot(param,qenergy,'.r','Markersize',18);
end

if nargin == 3
    for j = 1:length(ks)
        i = ks(j);
        q=path(i,1:NPTS);
        R = path(i,end);
        Beta = path(i,end-1);
        rho = R*q/2;

        [qenergy,qadsorption,qintegral] = measures(q,[Beta R]);
        figure(1);hold on;
        plot(params(i),qenergy,'.k','Markersize',18);
        
    end
end
end