function C = Nconv_lovett(V,U)

global NPTS dx Weights

%Cvv = zeros(1,N);
%for k = 1:N
%    for i = 1:N
%        Cvv(k) = Cvv(k) + V(k-i+N)*w(i)*U(i);
%    end
%end
%C = 2*Cvv/(N-1);
%plot(C,'ok');hold on;

U = Weights.*U;
U = [zeros(1,NPTS-1) U];
fU = fft(U);
Cu = real(ifft(fft(V).*fU));
Cv = [Cu(2*NPTS-1) Cu(1:NPTS-1)];
C = dx*Cv;

%plot(Cu,'xr');
%pause
return