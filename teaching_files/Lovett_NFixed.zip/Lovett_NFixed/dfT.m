function D=dfT(k,x,p)

global NPTS uPotential

k = k';
D = df(k,x,p)';

return