function [path,FindFold]=cont(x,p,ip,FindFold)

% Continue the solution of Fun(x,p)=0 in the ip-th parameter
% using x as the initial guess for a point on the curve.

global Beta StepsAroundCurve MaxNewtonIts tol dt NPTS dtMax dtMin gmtol restart gmsteps ContinuationParameters

path = zeros(StepsAroundCurve,NPTS + length(ContinuationParameters));

x0=x;
p0=p(ip);
disp(['* Starting continuation from input at parameter value * : ',num2str(p0)]);

Dp = pderiv(x0,p,ip);
RHS = zeros(1,NPTS+1);
RHS(NPTS+1) = 1;
[z0,gmresI] = cgs(@dfT,-Dp',gmtol,gmsteps,[],[],[],x0,p);
if not(gmresI==0)
    [z0,gmresI] = gmres(@dfT,-Dp',restart,gmtol,gmsteps,[],[],[],x0,p);
    if not(gmresI==0)
        disp('* Can''t find predictor, stopping *');
        path = [];
        return
    end
end
disp(['** Found initial predictor **']);
z0 = z0';

frac=sqrt(dot(z0,z0)+1);
s0 = z0/frac;
sig0= 1/frac;
opts.disp = 0;

for its=1:StepsAroundCurve,
  p(ip)=p0;

  xg=x0+dt*s0;
  pg=p0+dt*sig0;

  step=zeros(1,NPTS+1);
  w = zeros(1,NPTS+1);
  NewtonIts = 0;

  Dp = pderiv(xg,p,ip);
  error = 1;
  
  while (error > tol) && (NewtonIts<=MaxNewtonIts),

    p(ip)=pg;
    rhsx=-f(xg,p);

    opts.disp = 0;
    rhss=dt - s0*(xg-x0)' - sig0*(pg-p0);
    rhs=[rhsx,rhss];

    OldStep = step';
    %[step,gmflag] = gmres6(@fulldf2,rhs',restart,gmtol,gmsteps,[],[],OldStep,xg,p,Dp,s0,sig0);
    %[step,gmflag] = gmres(@fulldf2,rhs',restart,gmtol,gmsteps,[],[],OldStep,xg,p,Dp,s0,sig0);
    [step,gmflag] = cgs(@fulldf2,rhs',gmtol,gmsteps,[],[],[],xg,p,Dp,s0,sig0);
    if (gmflag > 0)
        [step,gmflag] = gmres(@fulldf2,rhs',restart,gmtol,gmsteps,[],[],OldStep,xg,p,Dp,s0,sig0);
        if (gmflag > 0)
           disp('CGS and GMRES not converging');
            path = path(1:its-1,:);
    %       disp('eigenvalues of derivative near ...');
    %       eigs(@fulldf2,NPTS,4,0,opts,xg,p,Dp,s0,sig0)
           return
        end
    end
    step = step';

%    eigs(@fulldf2,NPTS+1,1,0,opts,xg,p,Dp,s0,sig0)

    
    next=[xg,pg]+step;
    error = norm(step,inf)/norm(next,inf);
    xg=next(1:NPTS);
    pg=next(NPTS+1);
    p(ip)=pg;
    Dp = pderiv(xg,p,ip);

    NewtonIts = NewtonIts+1;
    
  end
  
  if (NewtonIts > MaxNewtonIts)
    disp('Newton method not converging');
    path = path(1:its-1,:);
    return
  end

  
  if (NewtonIts <= 3)
      dt = 19*dt/15;
      if (abs(dt) > dtMax)
          dt = dtMax*sign(dt);
      end
  end

  if (NewtonIts >= 4)
      dt = 2*dt/7;
      if (abs(dt) < dtMin)
          dt = dtMin*sign(dt);
      end
  end

  p(ip) = pg;
  path(its,:)=[xg(1:NPTS) p];

  OldW = w';
  %[w,gmflagw] = gmres(@fulldf2,RHS',restart,gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  %[w,gmflagw] = gmres(@fulldf2,RHS',restart,gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  [w,gmflagw] = cgs(@fulldf2,RHS',gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  if gmflagw > 0
    [w,gmflagw] = gmres(@fulldf2,RHS',restart,gmtol,gmsteps,[],[],OldW,xg,p,Dp,s0,sig0);
  end
  w = w';
  
  if (gmflagw > 0)
     path = path(1:its-1,:);
     disp('GMRES not converging in predictor step');
     disp('eigenvalues of derivative near ...');
     eigs(@dfT,NPTS,2,0,opts,xg,p)
     return
  end

  w=w./norm(w,2);
  s0=w(1:NPTS);
  sig0=w(NPTS+1);

  x0=xg;
  p0=pg;
  
  if (its > 2)
    folddetected = ((pg-path(its-1,NPTS+ip))*(path(its-1,NPTS+ip)-path(its-2,NPTS+ip)) < 0);
    if folddetected
        disp('======================');
        disp(['Found fold near ',num2str(pg)]);
        disp('======================');

        kF = xg-path(its-1,1:NPTS);
        kF = kF/norm(kF);
        foldPoint = [path(its-1,1:NPTS) kF p];
        FindFold = [FindFold ; foldPoint];
        disp(['Inf norm residual for codim-2 code is ',...
            num2str(norm(f_cd2(foldPoint(1:end-1),foldPoint(end)),inf))]);
        disp('======================');
        if FindFold == 1
            path = path(1:its,:);
            return
        end
    end
  end

  
  if mod(its,10)==0,
      disp([num2str(floor(100*its/StepsAroundCurve)),' Percent complete']);
      if (ip == 1)
          str = ['Last Beta equals ',num2str(pg)];
      else
          str = ['Last L equals ',num2str(pg)];
      end
      disp(str);
      disp(['Last no of Newton iterations is ',num2str(NewtonIts),' and dt = ',num2str(dt)]);
%      eigs(@fulldf2,NPTS+1,1,0,opts,xg,p,Dp,s0,sig0)
  end
  
end

return