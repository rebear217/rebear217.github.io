function myMesh(p,STEP)

global NPTS space ContinuationParameter ContinuationParameters

if nargin < 2
    STEP = 10;
end

params = p(1:STEP:end,end-1:end);
Ps = params(:,ContinuationParameter);

surf(space,Ps,p(1:STEP:end,1:end-2),'EdgeColor','none');
%mesh(space,Ps,p(1:STEP:end,1:end-3));

%shading faceted;
%axis off ij
%shading interp
colormap hsv
a = xlabel('Normalised space [-1,1]');
b = ylabel(ContinuationParameters(ContinuationParameter));
c = title('Density profile');
colorbar;
axis tight;
view(2);

set(b,'FontSize',12,'FontName','Aerial');
set(a,'FontSize',12,'FontName','Aerial');
set(c,'FontSize',12,'FontName','Aerial');
