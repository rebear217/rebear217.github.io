function solutionplot(path)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global Nparticles space NPTS ContinuationParameter ContinuationParameters

[n,m]=size(path);

oldparams = [0 0 0];
oldoldparams = [0 0 0];

figure(111);
for i=1:n,
 	R = path(i,end);
 	Beta = path(i,end-1);
    params = [Beta R];
    
    if (params(ContinuationParameter)-oldparams(ContinuationParameter))*(oldparams(ContinuationParameter)-oldoldparams(ContinuationParameter))<0
        str = 'Red';
        lw = 4;
    else
        str = 'Blue';
        lw = 1;
    end

    q=path(i,1:NPTS);

    a=plot(R*space/2,q,'-k');
    b=xlabel([' x \in [-L/2,L/2], where L = ',num2str(R)]);
    c=title(['Density profile for \beta = ',num2str(Beta)]);
    d=ylabel(' \rho(x)');
    axis([-R/2 R/2 min(q)-0.1 max(q)+0.1]);

    set(a,'LineWidth',lw,'Color',str);
    set(b,'FontSize',12,'FontName','Aerial');
    set(c,'FontSize',12,'FontName','Aerial');
    set(d,'FontSize',14,'FontName','Aerial');

    drawnow;
    oldoldparams = oldparams;
    oldparams = params;
end
