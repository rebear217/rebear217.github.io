function illustrate(path,posns,folds)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global Nparticles dx space ContinuationParameter ContinuationParameters NPTS space2 space

[n,m]=size(path);

K = length(posns);

if nargin < 3
    folds = [];
end

figure(1);
subplot(1,K+1,1);
bifdiag2(path,folds);hold on;
title('Bifurcation diagram','Fontsize',12);

for j=1:K
    L = posns(j);
    
 	params = path(L,NPTS+1:end);

    Beta = params(1);
    R = params(2);

    h = path(L,1:NPTS);
    [energy,adsorption,integral] = measures(h,params);
    subplot(1,K+1,1);hold on;
    plot(params(ContinuationParameter),energy,'.k','Markersize',18);

    subplot(1,K+1,j+1);hold off;
    
    a=plot((R/2)*space,h,'-k');axis tight;
%    b=xlabel([ContinuationParameters(ContinuationParameter),' = ',num2str(params(ContinuationParameter))]);
    b = xlabel('x');
    d=ylabel(' \rho(x)');

%    if j == 1
        c=title(['(N,\beta,L) = (',num2str(Nparticles),',',num2str(Beta),',',num2str(R),')' ]);
        set(c,'FontSize',12,'FontName','Aerial');
%    end

    
    set(gca,'LineWidth',1,'FontSize',12,'FontName','Aerial');
    set(a,'LineWidth',1);
    set(b,'FontSize',14,'FontName','Aerial');
    set(d,'FontSize',14,'FontName','Aerial');

end
