function bifdiag(path,folds)

% Plots the eigs and stability properties along the curve 'path' continue in param ip

global Nparticles dx space2 NPTS ContinuationParameter ContinuationParameters

if nargin == 1
    folds = [];
end

nParams = length(ContinuationParameters);

[n,m]=size(path);
params = zeros(n,1);
Norm2=zeros(n,1);

adsorption = zeros(n,1);
energy = zeros(n,1);
entropy = zeros(n,1);
mu = zeros(n,1);

disp('please wait');
for i=1:n,
    params(i) = path(i,NPTS + ContinuationParameter);
	q=path(i,1:NPTS);
 	R = path(i,end);
 	Beta = path(i,end-1);
    [energy(i),adsorption(i),entropy(i),mu(i)]= measures(q,[Beta R]);
end

figure(1);
subplot(1,2,1);hold on;

plot(params,adsorption,'-r');hold on;
xlabel(ContinuationParameters(ContinuationParameter),'FontSize',14,'FontName','Times');
ylabel('adsorption (\int_{-1}^1 |\rho(x)-\rho_m| dx/2)','FontSize',12,'FontName','Aerial') ;

subplot(1,2,2);hold on;
plot(params,energy,'-b','Linewidth',1);
if (ContinuationParameter==1)
    title(['Bifurcation diagram with N = ',num2str(Nparticles),' where L = ',num2str(R)],'FontSize',12,'FontName','Aerial');
else
    title(['Bifurcation diagram with N = ',num2str(Nparticles),' where \beta = ',num2str(Beta)],'FontSize',12,'FontName','Aerial');
end

ylabel('energy','FontSize',12);
xlabel(ContinuationParameters(ContinuationParameter),'FontSize',14,'FontSize',14,'FontName','Times');

[N,M] = size(folds);

if not(isempty(folds))
for i = 1:N
    param = folds(i,2*NPTS + ContinuationParameter);

	q=folds(i,1:NPTS);
%    k=folds(i,NPTS+1:2*NPTS);
 	z=folds(i,end-1);
 	R=folds(i,end);
    
    [qenergy,qadsorption,qentropy,qmu]= measures(q,[z R]);
    figure(1);
    subplot(1,2,1);hold on;
    plot(param,qadsorption,'.b','Markersize',18);
    subplot(1,2,2);hold on;
    plot(param,qenergy,'.r','Markersize',18);

end
end

return
