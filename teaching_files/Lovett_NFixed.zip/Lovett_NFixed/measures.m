function [energy,adsorption,entropy,mu] = measures(Q,p)

global dx space2 Weights space Nparticles

Beta = p(1);
L = p(2);

q = Q/Beta;

vkap = kap(space2,[Beta L]);
cstarQ = Nconv_lovett(vkap,q);
%if we assume to be at a solution then we can compute this as follows:
%cstarQ = log(Q/z);

Quadratic = 0.5*q.*cstarQ;
intQuadratic = dx*sum(Weights.*Quadratic);

%integral = dx*sum(Weights.*q);
%integral - Nparticles

adsorption = dx*norm(Weights.*(q-Nparticles/2),1)/2;

fugacity = Nparticles/(dx*sum(Weights.*exp(cstarQ)));
mu = log(fugacity)/Beta;

energy = (1/Beta)*dx*sum(Weights.*(q.*(reallog(2*q/L)-1))) - intQuadratic;

q = q/(dx*sum(Weights.*q));entropy = -dx*sum(Weights.*(q.*reallog(q)));

end